# Component equations and acceptance scope

This document describes the frozen new source candidate. It contains source reasoning, not simulated outcomes.

## Native load tray and signed interference

The untouched cargo is the supplied original3.2 kg Cannon `Body`, single0.78 m `Box`, original material, linear damping0.035 and angular damping0.16. The owned tray is4 kg; gravity is19.5 m/s². A62.4 N/m vertical spring has anchor2.65 m and explicit38 N·s/m damping. Consequently the static tray center is

\[
y_{empty}=2.65-\frac{4(19.5)}{62.4}=1.4\;m,
\qquad y_{loaded}=2.65-\frac{(4+3.2)(19.5)}{62.4}=0.4\;m.
\]

Only actual native contact can transmit cargo weight; no loaded flag occurs in the source. Sleeping original cargo on an enabled owned-body contact is normally woken before native mass-property update so that Cannon does not treat the supported load as infinite mass.

For the declared optical layout, a2 kg physical fine cart provides displacement \(q\in[-0.3,0.3]\) m and the tray current center is \(y\):

\[
L_r=35.5,\quad L_m=18.2+2y+2q,\quad\delta=L_r-L_m,\quad\lambda=4\;m.
\]

At source power80 W, arm transmissions \(t_r,t_m\in[0,1]\) give \(P_r=40t_r\), \(P_m=40t_m\). The two balanced detector powers are

\[
P_\pm=\frac{P_r+P_m\pm P_d}{2},\qquad
P_d=2\sqrt{P_rP_m}\cos(2\pi\delta/4).
\]

The physical receiver polarity is fixed: \(F_{wanted}=7P_d\), **retaining its sign**. Only the useful output-power budget uses an absolute value: \(P_{use}=0.4|P_d|\le32\) W. Removing either arm makes \(P_d=0\) algebraically, while each balanced detector may still receive equal light.

| Static input | Phase difference | Desired signed rack force |
| --- | --- | --- |
| Empty tray, cart anywhere in range |13.9…15.1 m | Maximum positive force≈87.60 N |
| Loaded tray, cart0 |16.5 m |≈395.98 N |
| Loaded tray, cart+0.25 m |16 m |560 N |
| Either arm missing | Any |0 N |

The negative empty endpoint has force magnitude over550 N. Replacing signed force with `abs(Pd)` would therefore create an empty-tray bypass. The source does not do that. Static force inequalities alone do not prove dynamic negatives during tray settling; the prepared native30 s tests must establish those independently.

## Real three-to-one transmission

The rack is1 kg and the vertical door8 kg. Their native equation uses spatial coefficients \([3,-1]\) with target at the declared initial positions. For rack displacement \(u\), door displacement is \(3u\), so

\[
M=1+8(3^2)=73\;kg,\qquad
Q_g=19.5(1+8\cdot3)=487.5\;N.
\]

Neither87.60 N empty nor395.98 N loaded-but-untuned can statically overcome gravity. The tuned560 N can overcome gravity plus the27 N/m rack spring over1.05 m rack travel. The door then travels3.15 m. Its ideal static lift work, including that spring, is

\[
W=487.5(1.05)+\tfrac12(27)(1.05)^2=526.75875\;J.
\]

Cannon's base `Equation.computeGiMGt` adds inverse masses assuming unit spatial rows. This row requires \(9/1+1/8=9.125\), so the owned linear-row class computes the full spatial norm and rotational term explicitly. The actual native constraints remain registered and solved by the native `GSSolver`.

For a scalar raw rack force \(F\), the appended projected forces are \(F/73\) on the rack and \(24F/73\) on the door. The explicit ideal gear reactions relative to raw rack force are \(-72F/73\) and \(24F/73\). Their ideal work is zero only when actual native displacements obey the3:1 relation; the measured finite error remains visible as signed reaction work.

## Why pending native forces are left alone

The inspected exact installed Cannon source calls native solve, removes solver rows, applies native damping, emits `preStep`, integrates body forces, clears forces, increments the step number, emits `postStep`, then updates sleep. The component owns the LAST preStep callback and FIRST postStep callback and rejects listener-order changes while active.

The native guide/gear solve already anticipates existing pending forces through its native `computeGiMf`. For zero-damping owned bodies the free end velocity before new actuator forces is \(v_{free}=v_{solved}+hF_{pending}/m\). Projecting **all** pending gravity again would double its ideal reaction. The source leaves that baseline untouched and appends only new motor, spring and damping forces with the reduced response.

Actual native contact/friction rows touching the mechanism temporarily use the symmetric reduced inverse mass operator. For rack/door Y coordinates:

\[
\bar M^{-1}=\frac1{73}\begin{bmatrix}1&3\\3&9\end{bmatrix}.
\]

Tray, fine cart and catch retain respectively their allowedY, X andX mass response; their blocked coordinates have zero response. Unowned bodies retain native inverse mass and world inverse inertia response. A contact on one linked body can therefore contribute native `vlambda` to its linked third body. The original contact `computeB`/`computeGiMf` stays responsible for its unprojected pending-force term; guide/gear compensation occurs once through the native rows. Native contact owners, shapes, normals and collision generation are retained.

Each temporary method descriptor is captured and restored after native solve, including failure paths. A zero-response row that is redundant with a guide contributes zero impulse. An actual fully blocked contact with penetration beyond0.05 mm throws instead of pretending to repair incompatible geometry. This contact projection is source-reviewed algebra; actual native penetration/convergence behavior remains untested.

## Force, power and physical manual controls

Springs and damping use a backward-Euler end-velocity solve after native damping. The fine cart has a bounded20 N command,20 W positive-work cap and5 N Coulomb brake. The actual0.5 kg sliding catch has an8 N/8 W manual command,4 N/m return spring and1 N·s/m damping. There is no logical latch. Its horizontal top face supports the door; its lower ramp is intended to be pushed aside by a rising door. The manual catch input can withdraw it so closing gravity and the explicit9000 N·s/m closing damper return the door.

For any commanded actuator force, a scalar bound is applied so predicted signed \(Fv_{end}\le P\). After native integration, actual raw port work must satisfy \(F\Delta x\le Ph+10^{-8}\) J. The motor's available force retains the signed detector difference throughout the bound. Forces have separate magnitude caps; negative work is signed absorption, not a free positive-power budget.

In the source ledger, `sourceWork = pressure.usefulWatts * h` means **available receiver output work budget**, at most32 W·h. It does not measure the80 W emitter's emitted optical energy or electrical input. `motorWork` is the separate actual signed raw motor-port work. The source does not close a full emitter/arm/detector/electrical energy balance or assert global passivity.

The source measures physical viscous/brake heat as \(-F_{diss}\Delta x\) and requires its nonnegative sign. Native solver stabilization is not added to these heat fields. Backward-Euler force and spring defects are separate explicit fields.

## Measured bookkeeping and its limit

For each measured body's translation, native backward-Euler integration gives

\[
\Delta K_{integration}=F_{total}\cdot\Delta x-\tfrac12m|v_{end}-v_{pre}|^2.
\]

The recorded one-step identity adds separately observed native solver kinetic change, known native damping loss and any foreign preStep kinetic change. Its1e−6 J bound is an integration/accounting check, **not a global conservation gate**. The original cargo's actual rotational/contact energy, arbitrary other bodies, room objects and solver/contact stabilization can exchange energy. Signed native solver work remains signed; it is never relabeled as physical heat. Native sleep happens after this ledger; `read()` exposes an observed native translational sleep removal separately.

Production LabPhysics also has later whole-game behavior outside this standalone world step. That behavior is not modeled or accepted here. The old impossible all-room1e−6 J energy gate is neither claimed nor silently replaced by a global pass.

## Proposed dynamic acceptance gates

Prepared checks require actual positive source/manual port budgets, signed-force and missing-arm algebra, real cargo contact and equilibrium, actual gear position error below5 mm and velocity error below0.02 m/s, correct door clearance, actual geometric catch support after optical power removal, paid manual release and physical return, row restoration, partial-setup rollback and normal disposal. The final1 s of power-off hold requires load-bearing native catch contact on at least90% of steps, door speed below0.02 m/s and clearance drift below1 cm. Wrong empty/untuned/missing-arm inputs must not clear a2.4 m doorway. These are proposed component thresholds and have not passed execution.

Later120/240 comparisons must inspect actual trajectories and reasonable convergence of clearance/contact/return, with no pose resynchronization. Held-cargo/proximity negatives, geometric ray causality, visuals and whole-room lifecycle are additional required production work, not waived by a component identity.
