/** PREPARED, NOT EXECUTED. Pick exactly one small case after source review.
 * No game, browser, renderer, portal tracer or MAIN source is started here.
 * Initial original cargo placement is fixture setup. There are no solved
 * body position/velocity assignments or success-state resynchronizations.
 */
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {Body,Box,ContactEquation,Equation,FrictionEquation,Material,Vec3,World}
  from '../../brainrot-portal/node_modules/cannon-es/dist/cannon-es.js';
import {Room48PhaseCell,ROOM48_PHASE_DESIGN as D,room48PhasePower}
  from './Room48PhaseCell.mjs';

const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const near=(a,b,e,label)=>assert.ok(Math.abs(a-b)<=e,`${label}: ${a} vs ${b} ±${e}`);
const started=performance.now();
const selected=process.argv.length===4&&process.argv[2]==='--case'?process.argv[3]:null;
const output={status:'PREPARED_CASE_RUNNING',case:selected,componentOnly:true,
  wholeRoomAccepted:false,originalCargoReplaced:false,solvedPoseResynchronization:false};

function fixture(loaded=false){
  const world=new World({gravity:new Vec3(0,-19.5,0),allowSleep:true});
  world.solver.iterations=40;world.solver.tolerance=1e-10;
  world.defaultContactMaterial.friction=.64;world.defaultContactMaterial.restitution=.08;
  world.defaultContactMaterial.contactEquationStiffness=1e8;world.defaultContactMaterial.contactEquationRelaxation=4;
  const floor=new Body({mass:0,position:new Vec3(-7,-.1,0),shape:new Box(new Vec3(1,.1,1)),
    material:new Material({friction:.64,restitution:0}),collisionFilterGroup:1,collisionFilterMask:2});
  const cargo=new Body({mass:3.2,position:loaded?new Vec3(-4,1.91,0):new Vec3(-7,.39,0),
    shape:new Box(new Vec3(.39,.39,.39)),material:new Material({friction:1,restitution:1}),
    linearDamping:.035,angularDamping:.16,allowSleep:true,sleepSpeedLimit:.11,sleepTimeLimit:.7,
    collisionFilterGroup:2,collisionFilterMask:1|4});
  world.addBody(floor);world.addBody(cargo);
  const baseline={bodies:[...world.bodies],constraints:[...world.constraints],pairs:[...world.contactmaterials],
    solve:world.solver.solve,solveDescriptor:Object.getOwnPropertyDescriptor(world.solver,'solve'),
    shape:cargo.shapes[0],material:cargo.material,pre:[...(world._listeners?.preStep??[])],post:[...(world._listeners?.postStep??[])]};
  const cell=new Room48PhaseCell(world,cargo);return{world,cargo,floor,cell,baseline};
}
function assertDisposed(f){
  const{world,cargo,cell,baseline:b}=f;cell.dispose();cell.dispose();
  assert.deepEqual(world.bodies,b.bodies);assert.deepEqual(world.constraints,b.constraints);assert.deepEqual(world.contactmaterials,b.pairs);
  assert.equal(world.solver.solve,b.solve);assert.deepEqual(Object.getOwnPropertyDescriptor(world.solver,'solve'),b.solveDescriptor);
  assert.deepEqual(world._listeners?.preStep??[],b.pre);assert.deepEqual(world._listeners?.postStep??[],b.post);
  assert.equal(cargo.world,world);assert.equal(cargo.shapes[0],b.shape);assert.equal(cargo.material,b.material);
  assert.equal(cargo.mass,3.2);assert.equal(cargo.linearDamping,.035);assert.equal(cargo.angularDamping,.16);
}
function run(f,{seconds,hz=120,targetQ=0,reference=1,measurement=1,catchPush=0}){
  assert.ok(seconds>0&&seconds<=36&&[120,240].includes(hz),'bounded declared fixture');
  const{world,cell}=f,dt=1/hz,n=Math.ceil(seconds*hz);
  const r={seconds:n/hz,hz,steps:n,maxDoor:-Infinity,maxGearPosition:0,maxGearVelocity:0,
    maxMotorBudgetExcess:-Infinity,maxFineBudgetExcess:-Infinity,maxCatchBudgetExcess:-Infinity,
    maxIntegrationResidual:0,minPhysicalHeat:Infinity,actualTrayContactSteps:0,actualCatchContactSteps:0,
    cargoWakes:0,maxMotorForce:0,maxFineForce:0,maxFineBrakeForce:0,maxCatchForce:0,
    finalWindow:{seconds:Math.min(n,hz)/hz,steps:0,loadBearingCatchSteps:0,minDoor:Infinity,maxDoor:-Infinity,maxDoorSpeed:0}};
  for(let i=0;i<n;i++){
    assert.ok(performance.now()-started<45000,'45s entire selected-case wall budget');
    const finePush=clamp(80*(targetQ-(cell.fine.position.x+4))-12*cell.fine.velocity.x,-1,1);
    cell.setInput({finePush,catchPush,reference,measurement});world.step(dt);const observation=cell.read(),s=observation.lastStep;
    r.maxDoor=Math.max(r.maxDoor,s.field.doorClearance);r.maxGearPosition=Math.max(r.maxGearPosition,Math.abs(s.gear.positionError));
    r.maxGearVelocity=Math.max(r.maxGearVelocity,Math.abs(s.gear.velocityError));
    r.maxMotorBudgetExcess=Math.max(r.maxMotorBudgetExcess,s.motorWork-s.sourceWork);
    r.maxFineBudgetExcess=Math.max(r.maxFineBudgetExcess,s.manualWork-D.fineWatts*dt);
    r.maxCatchBudgetExcess=Math.max(r.maxCatchBudgetExcess,s.catchManualWork-D.catchWatts*dt);
    r.maxIntegrationResidual=Math.max(r.maxIntegrationResidual,Math.abs(s.nativeTranslationalResidual));
    r.minPhysicalHeat=Math.min(r.minPhysicalHeat,...Object.values(s.heat));
    r.actualTrayContactSteps+=s.cargoTrayContacts.some(c=>c.multiplier>0)?1:0;
    const loadBearingCatch=world.contacts.some(c=>c.enabled&&c.multiplier>1&&((c.bi===cell.door&&c.bj===cell.dog&&-c.ni.y>.9)||(c.bj===cell.door&&c.bi===cell.dog&&c.ni.y>.9)));
    r.actualCatchContactSteps+=loadBearingCatch?1:0;
    if(i>=n-hz){const q=r.finalWindow;q.steps++;q.loadBearingCatchSteps+=loadBearingCatch?1:0;q.minDoor=Math.min(q.minDoor,s.field.doorClearance);q.maxDoor=Math.max(q.maxDoor,s.field.doorClearance);q.maxDoorSpeed=Math.max(q.maxDoorSpeed,Math.abs(cell.door.velocity.y));}
    r.cargoWakes+=s.wokeActualCargoContact?1:0;
    r.maxMotorForce=Math.max(r.maxMotorForce,Math.abs(s.forces.motor));r.maxFineForce=Math.max(r.maxFineForce,Math.abs(s.forces.fineForce));
    r.maxFineBrakeForce=Math.max(r.maxFineBrakeForce,Math.abs(s.forces.fineBrake));
    r.maxCatchForce=Math.max(r.maxCatchForce,Math.abs(s.forces.catchForce));
    // Native pooled row methods may not retain any per-step observer.
    assert.equal(cell.projectedRows.length,0);
    for(const row of [...world.contacts,...world.frictionEquations]){
      assert.ok(row instanceof ContactEquation||row instanceof FrictionEquation,'actual native narrowphase row');
      const expectedB=row instanceof ContactEquation?ContactEquation.prototype.computeB:FrictionEquation.prototype.computeB;
      assert.equal(row.computeB,expectedB,'pooled original native computeB');
      for(const key of ['computeGiMGt','computeGWlambda','addToWlambda'])assert.equal(row[key],Equation.prototype[key],'pooled original native '+key);
      for(const key of ['computeB','computeGiMGt','computeGWlambda','addToWlambda'])assert.equal(Object.getOwnPropertyDescriptor(row,key),undefined,'fixture pooled original inherited descriptor '+key);
      assert.ok(world.bodies.includes(row.bi)&&world.bodies.includes(row.bj),'actual native equation body owners');
      if(row instanceof ContactEquation){assert.equal(row.si.body,row.bi,'actual native contact shape A owner');assert.equal(row.sj.body,row.bj,'actual native contact shape B owner');}
    }
  }
  assert.ok(r.maxGearPosition<.005,'native 3:1 position error <5mm');
  assert.ok(r.maxGearVelocity<.02,'native 3:1 velocity error <.02m/s');
  assert.ok(r.maxMotorBudgetExcess<=1e-8&&r.maxFineBudgetExcess<=1e-8&&r.maxCatchBudgetExcess<=1e-8,'all actual positive port budgets');
  assert.ok(r.maxMotorForce<=560+1e-8&&r.maxFineForce<=20+1e-8&&r.maxFineBrakeForce<=5+1e-8&&r.maxCatchForce<=8+1e-8,'all physical force caps');
  assert.ok(r.maxIntegrationResidual<1e-6&&r.minPhysicalHeat>=-1e-8,'translation identity and actual dissipative signs');
  r.final=cell.read();return r;
}
function math(){
  const empty=room48PhasePower({trayY:1.4,fineQ:-.3});
  near(empty.desiredForce,560*Math.cos(2*Math.PI*15.1/4),1e-9,'empty signed force endpoint');
  assert.ok(empty.desiredForce>0&&empty.desiredForce<D.inputGravity);
  const emptyOther=room48PhasePower({trayY:1.4,fineQ:.3});assert.ok(emptyOther.desiredForce< -550,'negative phase remains negative force');
  const untuned=room48PhasePower({trayY:.4,fineQ:0});near(untuned.desiredForce,560/Math.sqrt(2),1e-9,'loaded untuned');assert.ok(untuned.desiredForce<D.inputGravity);
  const tuned=room48PhasePower({trayY:.4,fineQ:.25});near(tuned.delta,16,1e-12,'correct phase');near(tuned.desiredForce,560,1e-10,'tuned force');near(tuned.usefulWatts,32,1e-10,'tuned useful power');
  for(const [reference,measurement] of [[0,1],[1,0],[0,0]]){const p=room48PhasePower({trayY:.4,fineQ:.25,reference,measurement});assert.ok(p.difference===0&&p.desiredForce===0&&p.usefulWatts===0,'one missing actual arm means balanced zero');}
  return{emptyMaximumPositiveForce:empty.desiredForce,emptyOtherEndpointSignedForce:emptyOther.desiredForce,
    loadedUntunedForce:untuned.desiredForce,tunedForce:tuned.desiredForce,tunedUsefulWatts:tuned.usefulWatts,
    staticLiftWork:D.inputGravity*D.rackTravel+.5*D.rackSpring*D.rackTravel**2};
}
function metric(){
  const f=fixture();try{
    for(const b of f.cell.ownedDynamic)b.updateSolveMassProperties();f.floor.updateSolveMassProperties();
    near(f.cell.gear.equations[0].computeGiMGt(),9+1/8,1e-14,'full spatial native gear row');
    // Unit probe of the operator, explicitly not a narrowphase contact proof.
    const row=new ContactEquation(f.cell.rack,f.floor);row.jacobianElementA.spatial.set(0,1,0);row.jacobianElementB.spatial.set(0,0,0);
    const p=f.cell._response(row);near(p.metric,1/73,1e-14,'projected rack contact metric');near(p.response.get(f.cell.door).linear.y,3/73,1e-14,'linked third-body response');
    const shape=f.cell.dog.shapes[0],center=new Vec3();for(const v of shape.vertices)center.vadd(v,center);center.scale(1/shape.vertices.length,center);
    for(let i=0;i<shape.faces.length;i++){const face=shape.faces[i],normal=shape.faceNormals[i],vertex=shape.vertices[face[0]];
      near(normal.length(),1,1e-12,'native catch unit normal');assert.ok(normal.dot(center.vsub(vertex))< -1e-6,'native catch interior behind outward plane');
      for(const v of shape.vertices)assert.ok(normal.dot(v.vsub(vertex))<=1e-10,'every actual catch vertex behind native convex face');
    }
    assert.ok(shape.faceNormals.some(n=>n.y>.999)&&shape.faceNormals.some(n=>n.y< -.9&&n.x>0),'actual upper keeper and downward entry ramp normals');
    return{nativeGearMetric:9+1/8,reducedRackContactMetric:p.metric,catchOutwardFaces:shape.faces.length,operatorUnitOnly:true};
  }finally{assertDisposed(f);}
}
function oneStep(){const f=fixture(true);try{return run(f,{seconds:1/120,targetQ:.25});}finally{assertDisposed(f);}}
function loaded(hz=120,returnCycle=false){
  const f=fixture(true);try{
    const lift=run(f,{seconds:32,hz,targetQ:.25});assert.ok(lift.final.lastStep.field.doorClearance>2.9,'correct loaded native lift clears door');
    near(lift.final.lastStep.field.trayY,.4,.035,'actual loaded tray equilibrium');assert.ok(lift.actualTrayContactSteps>hz,'actual original cargo/tray contact');
    const hold=run(f,{seconds:3,hz,targetQ:.25,reference:0}),window=hold.finalWindow;
    assert.ok(window.minDoor>2.75,'native geometric catch holds clear with optical difference zero');
    assert.ok(window.loadBearingCatchSteps>=.9*window.steps,'final1s persistent actual load-bearing catch owner rows');
    assert.ok(window.maxDoorSpeed<.02&&window.maxDoor-window.minDoor<.01,'final1s bounded speed and clearance drift while caught');
    if(!returnCycle)return{lift,hold};
    const closing=run(f,{seconds:30,hz,targetQ:.25,reference:0,catchPush:-1});assert.ok(closing.final.lastStep.field.doorClearance<.15,'paid actual dog withdrawal permits physical return');return{lift,hold,closing};
  }finally{assertDisposed(f);}
}
function negative(kind){
  const loadedCargo=kind!=='empty',f=fixture(loadedCargo);try{
    const input=kind==='empty'?{targetQ:-.3}:kind==='untuned'?{targetQ:0}:kind==='missing-reference'?{targetQ:.25,reference:0}:{targetQ:.25,measurement:0};
    const r=run(f,{seconds:30,...input});assert.ok(r.maxDoor<2.4,'wrong input cannot physically clear a2.4m opening');
    near(r.final.lastStep.field.trayY,loadedCargo ? .4 : 1.4,.035,'actual contact-dependent tray equilibrium');return{kind,...r};
  }finally{assertDisposed(f);}
}
function lifecycle(){
  const f=fixture(true),{world,cell}=f;run(f,{seconds:1/120});
  const foreign=()=>{};world.addEventListener('preStep',foreign);
  const oldPre=world._listeners.preStep;world._listeners.preStep=[...oldPre];
  cell.dispose();assert.ok(!oldPre.includes(cell.pre)&&!world._listeners.preStep.includes(cell.pre),'both owned listener array references cleaned');
  assert.ok(world.hasEventListener('preStep',foreign),'foreign listener preserved');world.removeEventListener('preStep',foreign);assertDisposed(f);
  const bad=fixture();bad.cell.dispose();bad.cargo.mass=9;const count=bad.world.bodies.length;assert.throws(()=>new Room48PhaseCell(bad.world,bad.cargo),/original3.2kg/);assert.equal(bad.world.bodies.length,count,'invalid original rejected before owned setup');
  const interrupted=fixture();interrupted.cell.dispose();const b=[...interrupted.world.bodies],handler=()=>{throw Error('declared setup interruption');};interrupted.world.addEventListener('addBody',handler);
  assert.throws(()=>new Room48PhaseCell(interrupted.world,interrupted.cargo),/declared setup interruption/);interrupted.world.removeEventListener('addBody',handler);assert.deepEqual(interrupted.world.bodies,b,'partial native add event setup rolls back');
  return{normalDispose:true,foreignListenerPreserved:true,clonedListenerArrayCleaned:true,invalidCargoRejected:true,partialSetupRollback:true};
}
const cases={math,metric,'one-step':oneStep,'loaded-120':()=>loaded(120),'return-120':()=>loaded(120,true),
  'empty-negative':()=>negative('empty'),'untuned-negative':()=>negative('untuned'),
  'missing-reference':()=>negative('missing-reference'),'missing-measurement':()=>negative('missing-measurement'),
  lifecycle,'loaded-240':()=>loaded(240)};
if(!Object.hasOwn(cases,selected)){process.stderr.write('Prepared only. After approval select exactly one --case: '+Object.keys(cases).join(', ')+'\n');process.exitCode=2;}
else{try{output.result=cases[selected]();output.status='SELECTED_COMPONENT_CASE_PASS';}catch(error){output.status='SELECTED_COMPONENT_CASE_FAIL';output.error=String(error.stack??error);process.exitCode=1;}output.elapsedMs=performance.now()-started;process.stdout.write(JSON.stringify(output)+'\n');}
