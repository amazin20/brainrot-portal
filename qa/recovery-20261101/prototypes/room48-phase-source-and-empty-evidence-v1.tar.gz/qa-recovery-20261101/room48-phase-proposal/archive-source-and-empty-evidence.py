"""Archive existing source/receipts only; no native/browser execution."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path

base=Path(__file__).resolve().parent;scratch=base.parent.parent
destination=base.parent/'room48-phase-proof-archive';destination.mkdir(exist_ok=True)
archive=destination/'room48-phase-source-and-empty-evidence-v1.tar.gz'
manifest=destination/'room48-phase-source-and-empty-evidence-v1.manifest.json'
assert not archive.exists() and not manifest.exists(),'Never overwrite a prior proof archive.'
assert (base/'independent-actual-empty-negative-review.json').is_file(),'Archive after independent full-raw review.'
def sha(p):
 digest=hashlib.sha256()
 with p.open('rb') as stream:
  while True:
   chunk=stream.read(256*1024)
   if not chunk:break
   digest.update(chunk)
 return digest.hexdigest()
assert sha(base/'Room48PhaseCell.mjs')=='73fc8dc55b288e8f693b8935f6d390e1ab94b7f28e853f013124a85384ec793a'
assert sha(base/'prepared-checks.mjs')=='38d9b5e478d4c5cd70f1a35672ff0008a802875db5ed9daf9a1666ea4e8ec693'
files=sorted(p for p in base.rglob('*') if p.is_file())
files+=list(scratch/'brainrot-portal/node_modules/cannon-es'/rel for rel in ['dist/cannon-es.js','package.json'])
files=sorted(files,key=lambda p:str(p.relative_to(scratch)))
entries=[{'path':str(p.relative_to(scratch)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
scope={'status':'SOURCE_AND_FOUR_SELECTED_CASES_ONLY','acceptedActualCases':['math','metric','one-step','empty-negative'],
 'emptyNegativeActualSteps':3600,'emptyNegativeHz':120,'emptyNegativeSimulatedSeconds':30,
 'fullRawJsonlPreserved':True,'originalStderrPreserved':True,'componentSha256':sha(base/'Room48PhaseCell.mjs'),
 'checksSha256':sha(base/'prepared-checks.mjs'),'wholeRoomAccepted':False,'loadedLiftAccepted':False,'catchAccepted':False,
 'realRayGeometryAccepted':False,'visualAcceptance':False,'globalConservationOrPassivity':False,
 'note':'Initial SOURCE_ONLY docs/reviews are historical preparation snapshots. Actual receipts, EVIDENCE_SCOPE and independent actual review define current runtime evidence. Superseded winding review remains explicitly marked. Archive stores exact native Cannon reference and original relative paths; no production integration.'}
contents=json.dumps({'scope':scope,'files':entries},indent=2).encode()+b'\n'
def serialize(path):
 with path.open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as compressed:
   with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
    for entry,p in zip(entries,files):
     info=tarfile.TarInfo(entry['path']);info.size=entry['bytes'];info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
     with p.open('rb') as f:tar.addfile(info,f)
    info=tarfile.TarInfo('ARCHIVE_CONTENTS.json');info.size=len(contents);info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;tar.addfile(info,io.BytesIO(contents))
partial=archive.with_suffix('.partial');repeat=archive.with_suffix('.repeat')
serialize(partial)
expected={e['path']:e for e in entries};expected['ARCHIVE_CONTENTS.json']={'bytes':len(contents),'sha256':hashlib.sha256(contents).hexdigest()}
verified=[]
with tarfile.open(partial,'r:gz') as tar:
 for member in tar:
  assert member.isfile() and member.name in expected
  digest=hashlib.sha256();size=0
  with tar.extractfile(member) as stream:
   while True:
    chunk=stream.read(256*1024)
    if not chunk:break
    size+=len(chunk);digest.update(chunk)
  assert size==expected[member.name]['bytes'] and digest.hexdigest()==expected[member.name]['sha256']
  verified.append(member.name)
assert sorted(verified)==sorted(expected)
assert all(sha(p)==e['sha256'] for p,e in zip(files,entries)),'Input mutation during archival.'
serialize(repeat);assert sha(repeat)==sha(partial),'Deterministic repeat serialization differs.';repeat.unlink();partial.rename(archive)
result={'archive':str(archive),'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive),
 'sourcePayloadFiles':len(entries),'archiveEntries':len(verified),'uncompressedPayloadBytes':sum(e['bytes'] for e in entries)+len(contents),
 'scope':scope,'files':entries,'nativeCannonReferenceIncluded':True,'allEntriesVerifiedAfterDecompression':True,'repeatSerializationSameSha256':True,
 'qaOnlyOutsideMain':True,'nativeExecutionDuringArchival':False,'productionMutationsDuringArchival':False}
manifest.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['files']},indent=2))
