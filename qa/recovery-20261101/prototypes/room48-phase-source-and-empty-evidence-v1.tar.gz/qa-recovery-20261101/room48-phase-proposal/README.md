# New room48 phase and native gear proposal

**SOURCE ONLY — NOT EXECUTED.** This is a new isolated component, not restored lost source, a live room, a campaign change, or a record of passing tests. No Node, Cannon simulation, browser, renderer or game route was started while preparing it. Production `src`, `scripts`, `tests` and `public` remain outside this proposal.

The current display48/index48 production puzzle repeats the early mirror/weight mechanic. The proposed replacement asks the player to load an actual spring tray with the original cargo, then move a separate optical carriage to obtain constructive interference. Two optical arms feed a balanced receiver; their **signed** difference drives a native three-to-one rack/door mechanism. A real sliding wedge catches the raised door. The player can withdraw that wedge through a bounded manual force input and let the door close physically.

Files:

| File | Purpose |
| --- | --- |
| `Room48PhaseCell.mjs` | New native Cannon component; exact original cargo passed into constructor |
| `MATH.md` | Physical choices, solver ordering, source equations and acceptance limits |
| `prepared-checks.mjs` | Prepared individually selected checks; not run |
| `independent-source-review.json` | Independent reading review bound to the component SHA; no execution proof |

The component creates only its own machine bodies at setup. It does not write solved body positions, orientations or velocities after setup, replace the cargo, introduce a loaded flag, use a success latch, multiply available power by pickup state, or change original cargo material/shape/mass/damping. A native `wakeUp()` call is permitted only for that original sleeping cargo on an enabled actual contact with an owned dynamic body. Pickup/release may legitimately change its ordinary sleep/filter controls; those are not optical permission inputs.

`setInput({finePush, catchPush, reference, measurement})` accepts bounded manual commands and declared optical transmissions. `world.step(dt)` stays native. `read()` observes the native result and signed ledgers. `dispose()` removes only owned resources, restores all temporary pooled contact methods, restores the original solver method, and retains the original cargo. Setup exceptions attempt the same cleanup.

The carriage and catch manual ports are separate external sources (20 N/20 W and 8 N/8 W). Their actual signed force/displacement work is reported separately from the 80 W optical source and at most32 W receiver output. The catch port can withdraw the actual dog; it cannot directly push the rack or door.

The ledger field `sourceWork` is a historical name for **available receiver output work budget**: `usefulWatts * dt`, at most32 W·dt. It is not the80 W emitter's electrical or emitted optical energy, nor actual delivered motor work (reported separately as `motorWork`). No full-source energy or global passivity claim follows from it.

## Required review before any execution

The parent agent must review the component, equations and prepared small checks first. The initial authorized execution should be one selected case, not the whole list. The file requires an explicit `--case`; omission exits without stepping a world. A suitable later sequence is `math`, `metric`, `one-step`, then individual negative/lift/lifecycle cases. Each selected case checks a45 s wall budget inside its step loop and is intended for a128 MiB Node cap. An external timeout is still required because an individual synchronous native solver call cannot observe the loop deadline.

Prepared case names: `math`, `metric`, `one-step`, `empty-negative`, `untuned-negative`, `missing-reference`, `missing-measurement`, `loaded-120`, `return-120`, `lifecycle`, `loaded-240`.

The prepared files and asserted thresholds are **proposed checks**, not observations or proof. Any failure requires reporting and investigation; no geometric/causal check may be dropped to obtain a pass.120/240 results need a separate comparison of actual tray position, gear errors, clearance, catch behavior and return trajectory. A small translational integration identity does not establish whole-room conservation.

## Still open before production acceptance

The formula lengths in this component are a declared geometry abstraction only. A future live builder must construct and trace **both actual portal/ray arms**, sum actual segment lengths from current world poses, preserve the signed balanced receiver, and establish occlusion/arm removal causality. The live component must consume those real traced values instead of inferring loading from a flag. The source currently derives the prototype measurement length from actual tray and fine-body world positions, with fixed geometry constants; it is not a portal implementation.

The room still needs a unique complete GLB/visible beam layout, collision housing, ordinary player interaction targets, reach/held-cargo/proximity negatives, ray owner checks, route/door clearance testing, fresh120/240 native results, repeated enter/leave cleanup, and whole-campaign visual review. Forcefully holding another object against a real tray is a physical external load, not something a boolean should hide; room geometry and normal interaction reach must make any intended restriction meaningful.

No screenshot, visual-quality pass, live-room integration, old lost prototype pass, or whole-campaign acceptance is claimed here.
