"""Read existing actual JSONL only. Never imports/runs JS or native physics."""
import hashlib,json,math
from pathlib import Path

base=Path(__file__).resolve().parent;run=base/'actual-empty-negative-120-full'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stdout=json.loads((run/'stdout.json').read_text());receipt=json.loads((run/'receipt.json').read_text())
assert stdout['status']=='SELECTED_COMPONENT_CASE_PASS' and receipt['exitCode']==0 and receipt['abort'] is None
assert receipt['childProcessReaped'] and receipt['chromeProcessesAfter']==[]
assert receipt['globalPeakBytes']<6*1024**3
for name,meta in receipt['files'].items():assert sha(run/name)==meta['sha256']
names={'rack':'48 / input rack','door':'48 / native three-to-one gate','tray':'48 / actual load tray','fine':'48 / manual optical carriage','dog':'48 / sliding geometric catch'}
previous={'rack':.25,'door':1.2,'tray':1.4,'fine':-4,'dog':.5}
maxima={'doorClearance':-math.inf,'absoluteGearPosition':0,'absoluteGearVelocity':0,'motorBudgetExcess':-math.inf,'fineBudgetExcess':-math.inf,'catchBudgetExcess':-math.inf,'integrationResidual':0,'workRecomputationError':0,'positiveMotorForce':0,'absoluteMotorForce':0,'fineForce':0,'fineBrakeForce':0,'catchForce':0}
counts={'completedActualSteps':0,'actualNormalRows':0,'actualFrictionRows':0,'cargoTrayPositiveLoadSteps':0,'actualCatchPositiveLoadSteps':0,'actualCargoWakeSteps':0,'sleepingCargoSteps':0}
minimum_heat=math.inf;sums={};header=footer=None;actual_ids=None
with (run/'actual-steps.jsonl').open() as stream:
 for line_number,line in enumerate(stream,1):
  r=json.loads(line)
  if r['kind']=='header':assert line_number==1;header=r;continue
  if r['kind']=='finalBoundary':footer=r;continue
  assert r['kind']=='completedActualStep' and footer is None
  counts['completedActualSteps']+=1;n=counts['completedActualSteps'];o=r['observation'];s=o['lastStep'];dt=s['dt']
  assert n==r['nativeStep']==o['steps']==s['step'];assert dt==1/120
  assert r['input']['reference']==r['input']['measurement']==1 and r['input']['catchPush']==0
  assert all(math.isfinite(v) for v in s['field'].values())
  bodies={b['name']:b for b in r['bodies'] if b['name'] is not None};ids={b['id'] for b in r['bodies']}
  assert len(ids)==17 and len(r['worldConstraints'])==6
  if actual_ids is None:actual_ids={k:bodies[v]['id'] for k,v in names.items()}
  else:assert actual_ids=={k:bodies[v]['id'] for k,v in names.items()}
  p={k:bodies[v]['position'][0 if k in ['fine','dog'] else 1] for k,v in names.items()}
  delta={k:p[k]-previous[k] for k in previous};f=s['forces']
  measured={'motorWork':f['motor']*delta['rack'],'manualWork':f['fineForce']*delta['fine'],'catchManualWork':f['catchForce']*delta['dog'],'sourceWork':s['optics']['usefulWatts']*dt}
  for key,value in measured.items():
   err=abs(value-s[key]);maxima['workRecomputationError']=max(maxima['workRecomputationError'],err);assert err<1e-12
   sums[key]=sums.get(key,0)+value
  maxima['doorClearance']=max(maxima['doorClearance'],p['door']-1.2)
  maxima['absoluteGearPosition']=max(maxima['absoluteGearPosition'],abs(3*(p['rack']-.25)-(p['door']-1.2)))
  maxima['absoluteGearVelocity']=max(maxima['absoluteGearVelocity'],abs(3*bodies[names['rack']]['velocity'][1]-bodies[names['door']]['velocity'][1]))
  for key,value in [('motorBudgetExcess',measured['motorWork']-measured['sourceWork']),('fineBudgetExcess',measured['manualWork']-20*dt),('catchBudgetExcess',measured['catchManualWork']-8*dt),('integrationResidual',abs(s['nativeTranslationalResidual'])),('positiveMotorForce',f['motor']),('absoluteMotorForce',abs(f['motor'])),('fineForce',abs(f['fineForce'])),('fineBrakeForce',abs(f['fineBrake'])),('catchForce',abs(f['catchForce']))]:maxima[key]=max(maxima[key],value)
  minimum_heat=min(minimum_heat,*s['heat'].values())
  expected_heat={'closing':-f['closer']*delta['rack'],'tray':-f['trayDamp']*delta['tray'],'dog':-f['dogDamp']*delta['dog'],'fine':-f['fineBrake']*delta['fine']}
  for key,value in expected_heat.items():assert abs(value-s['heat'][key])<1e-12
  counts['cargoTrayPositiveLoadSteps']+=any(c['multiplier']>0 for c in s['cargoTrayContacts'])
  counts['actualCatchPositiveLoadSteps']+=any(c['enabled'] and c['multiplier']>0 and {c['bodyA'],c['bodyB']}=={actual_ids['dog'],actual_ids['door']} for c in r['contacts'])
  counts['actualCargoWakeSteps']+=s['wokeActualCargoContact']
  cargo=next(b for b in r['bodies'] if b['id']==1);assert cargo['mass']==3.2 and cargo['linearDamping']==.035 and cargo['angularDamping']==.16
  assert len(cargo['shapes'])==1 and cargo['shapes'][0]['id']==2 and cargo['shapes'][0]['half']==[.39]*3
  counts['sleepingCargoSteps']+=cargo['sleepState']==2
  for row in r['contacts']+r['frictionRows']:
   assert row['bodyA'] in ids and row['bodyB'] in ids and row['restoredNativeMethods'] and row['ownMethodDescriptors']==[]
   if row['kind']=='actualContact':assert row['shapeOwnerA']==row['bodyA'] and row['shapeOwnerB']==row['bodyB'];counts['actualNormalRows']+=1
   else:assert row['kind']=='actualFriction';counts['actualFrictionRows']+=1
  previous=p
assert counts['completedActualSteps']==3600 and header['expectedSteps']==3600
assert footer['completedActualStepRecords']==3600 and footer['processExitCode']==0
assert footer['sourceUnchanged'] and footer['checksUnchanged'] and footer['cellMethodsRestored']
assert footer['observations']==1 and len(footer['owners'])==1
owner=footer['owners'][0];assert owner['steps']==3600 and owner['worldStepnumber']==3600 and owner['disposed'] and owner['fault'] is None and owner['cleanupErrors']==[]
assert len(owner['worldBodies'])==2 and owner['worldConstraints']==0 and owner['originalCargo']['id']==1 and owner['originalCargo']['shapes'][0]['id']==2
assert maxima['doorClearance']<2.4 and maxima['absoluteGearPosition']<.005 and maxima['absoluteGearVelocity']<.02
assert maxima['motorBudgetExcess']<=1e-8 and maxima['fineBudgetExcess']<=1e-8 and maxima['catchBudgetExcess']<=1e-8
assert maxima['integrationResidual']<1e-6 and minimum_heat>=-1e-8
assert maxima['absoluteMotorForce']<=560+1e-8 and maxima['fineForce']<=20+1e-8 and maxima['fineBrakeForce']<=5+1e-8 and maxima['catchForce']<=8+1e-8
for key,value in sums.items():assert abs(value-stdout['result']['final']['sums'][key])<1e-10
result={'status':'ACTUAL_RECORDED_EMPTY_NEGATIVE_REVIEW_PASS','analysisOnlyNoNativeExecution':True,'case':'empty-negative','counts':counts,'maxima':maxima,'minimumPhysicalHeatJ':minimum_heat,'summedMeasuredPortWorkJ':sums,'finalFields':stdout['result']['final']['lastStep']['field'],'signedNativeSolverKineticDeltaJ':stdout['result']['final']['sums']['nativeSolverKineticDelta'],'forceBackwardEulerDefectJ':stdout['result']['final']['sums']['forceBackwardEulerDefect'],'physicalClosingHeatJ':stdout['result']['final']['sums']['closingHeat'],'nativeStderrPreserved':{'bytes':(run/'stderr.txt').stat().st_size,'sha256':sha(run/'stderr.txt'),'text':(run/'stderr.txt').read_text()},'sourceSha256':sha(base/'Room48PhaseCell.mjs'),'checksSha256':sha(base/'prepared-checks.mjs'),'rawJsonlSha256':sha(run/'actual-steps.jsonl'),'receiptSha256':sha(run/'receipt.json'),'scope':'Only declared30s120Hz empty trajectory with actual fine-force control targeting−.3; cart settled−.296875. No positive loaded/catch/return/arm-removal, full-range dynamic, real rays, visuals or live-room acceptance. sourceWork is available receiver output budget, not emitter energy. Signed native solver work is not heat or global passivity.'}
(base/'actual-empty-negative-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
