"""Only the parent-authorized empty-negative run; no Chrome overlap permitted."""
import hashlib,json,os,resource,signal,subprocess,time
from pathlib import Path

base=Path(__file__).resolve().parent
out=base/'actual-empty-negative-120-full'
assert not out.exists(),'Never overwrite an actual receipt.'
source=base/'Room48PhaseCell.mjs';checks=base/'prepared-checks.mjs';bootstrap=base/'observe-empty-negative-once.mjs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source)=='73fc8dc55b288e8f693b8935f6d390e1ab94b7f28e853f013124a85384ec793a'
assert sha(checks)=='38d9b5e478d4c5cd70f1a35672ff0008a802875db5ed9daf9a1666ea4e8ec693'
freeze={p.name:sha(p) for p in base.iterdir() if p.is_file()}
def chrome_processes():
 found=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:comm=(p/'comm').read_text().strip().lower()
  except (FileNotFoundError,PermissionError,ProcessLookupError):continue
  if comm in ['chrome','chromium','chromium-browse','headless_shell','chrome_crashpad'] or comm.startswith('chrome_'):
   found.append({'pid':int(p.name),'comm':comm})
 return found
assert not chrome_processes(),'All Chrome processes must be closed before this only runtime slot.'
initial_memory=int(Path('/sys/fs/cgroup/memory.current').read_text())
assert initial_memory<6*1024**3,'Initial global memory is already over6GiB.'
out.mkdir();start=time.monotonic();samples=[];abort=None
command=['timeout','-k','2s','45s','node','--max-old-space-size=128',str(bootstrap),'--ledger-dir',str(out)]
with (out/'stdout.json').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
 proc=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True)
 while proc.poll() is None:
  used=int(Path('/sys/fs/cgroup/memory.current').read_text());chromes=chrome_processes()
  samples.append({'seconds':time.monotonic()-start,'globalBytes':used,'chromeProcesses':chromes})
  if used>6*1024**3:abort='global memory exceeded6GiB'
  if chromes:abort='Chrome appeared during exclusive runtime slot'
  if time.monotonic()-start>48:abort='external deadline watchdog'
  if abort:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL)
   break
  time.sleep(.1)
 code=proc.wait(timeout=3)
post={p.name:sha(p) for p in base.iterdir() if p.is_file()}
assert freeze==post,'Read-only execution changed a proposal source file.'
chrome_after=chrome_processes()
receipt={'case':'empty-negative','hz':120,'requestedSimulatedSeconds':30,'exitCode':code,'abort':abort,
 'wallSeconds':time.monotonic()-start,'rssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
 'globalPeakBytes':max([initial_memory]+[s['globalBytes'] for s in samples]),'samples100ms':samples,
 'allChromeClosedAtStart':True,'chromeProcessesAfter':chrome_after,'childProcessReaped':proc.poll() is not None,
 'sourceUnchanged':True,'checksUnchanged':True,'sourceSha256':sha(source),'checksSha256':sha(checks),
 'bootstrapSha256':sha(bootstrap),'guardSha256':sha(Path(__file__)),
 'command':command,'componentOnly':True,'wholeRoomAccepted':False,
 'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='samples100ms'}))
raise SystemExit(code if not abort else 1)
