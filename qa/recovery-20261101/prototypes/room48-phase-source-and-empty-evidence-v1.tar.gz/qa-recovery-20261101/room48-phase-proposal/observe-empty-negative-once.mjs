/** Logging-only bootstrap for exactly the reviewed empty-negative case.
 * The original component/check files are imported unchanged. No World or
 * body physics method is replaced; only existing cell read/setInput calls
 * are observed and synchronously serialized after their native return.
 */
import {openSync,closeSync,writeSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {ContactEquation,Equation,FrictionEquation} from '../../brainrot-portal/node_modules/cannon-es/dist/cannon-es.js';
import {Room48PhaseCell} from './Room48PhaseCell.mjs';

if(process.argv.length!==4||process.argv[2]!=='--ledger-dir')throw Error('Exactly one --ledger-dir required; case is fixed empty-negative.');
const out=resolve(process.argv[3]),fd=openSync(join(out,'actual-steps.jsonl'),'wx');
const source=fileURLToPath(new URL('./Room48PhaseCell.mjs',import.meta.url)),checks=fileURLToPath(new URL('./prepared-checks.mjs',import.meta.url));
const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const expectedSource='73fc8dc55b288e8f693b8935f6d390e1ab94b7f28e853f013124a85384ec793a',expectedChecks='38d9b5e478d4c5cd70f1a35672ff0008a802875db5ed9daf9a1666ea4e8ec693';
if(sha(source)!==expectedSource||sha(checks)!==expectedChecks)throw Error('Frozen source/check hashes differ.');
const vector=v=>[v.x,v.y,v.z],quat=q=>[q.x,q.y,q.z,q.w];
let records=0,completed=0,bytes=0;
function emit(value){const buffer=Buffer.from(JSON.stringify(value)+'\n');let offset=0;while(offset<buffer.length)offset+=writeSync(fd,buffer,offset,buffer.length-offset);records++;bytes+=buffer.length;}
const state=b=>({id:b.id,name:b.name??null,type:b.type,mass:b.mass,inverseMass:b.invMass,worldOwner:b.world===null?null:b.world?.id??'actualWorld',
  position:vector(b.position),velocity:vector(b.velocity),angularVelocity:vector(b.angularVelocity),quaternion:quat(b.quaternion),
  pendingForce:vector(b.force),pendingTorque:vector(b.torque),sleepState:b.sleepState,allowSleep:b.allowSleep,
  linearDamping:b.linearDamping,angularDamping:b.angularDamping,group:b.collisionFilterGroup,mask:b.collisionFilterMask,
  materialId:b.material?.id??null,shapes:b.shapes.map(s=>({id:s.id,type:s.type,bodyOwnerId:s.body?.id??null,half:s.halfExtents?vector(s.halfExtents):null}))});
const row=e=>({id:e.id,kind:e instanceof ContactEquation?'actualContact':e instanceof FrictionEquation?'actualFriction':'unexpected',
  enabled:e.enabled,bodyA:e.bi.id,bodyB:e.bj.id,shapeA:e.si?.id??null,shapeB:e.sj?.id??null,
  shapeOwnerA:e.si?.body?.id??null,shapeOwnerB:e.sj?.body?.id??null,multiplier:e.multiplier,minForce:e.minForce,maxForce:e.maxForce,
  normal:e.ni?vector(e.ni):null,tangent:e.t?vector(e.t):null,pointA:e.ri?vector(e.ri):null,pointB:e.rj?vector(e.rj):null,
  jacobianA:{spatial:vector(e.jacobianElementA.spatial),rotational:vector(e.jacobianElementA.rotational)},
  jacobianB:{spatial:vector(e.jacobianElementB.spatial),rotational:vector(e.jacobianElementB.rotational)},
  restoredNativeMethods:e.computeB===(e instanceof ContactEquation?ContactEquation.prototype.computeB:FrictionEquation.prototype.computeB)&&
    ['computeGiMGt','computeGWlambda','addToWlambda'].every(k=>e[k]===Equation.prototype[k]),
  ownMethodDescriptors:['computeB','computeGiMGt','computeGWlambda','addToWlambda'].filter(k=>Object.hasOwn(e,k))});
const cells=new Set(),lastLogged=new WeakMap(),proto=Room48PhaseCell.prototype;
const readDescriptor=Object.getOwnPropertyDescriptor(proto,'read'),inputDescriptor=Object.getOwnPropertyDescriptor(proto,'setInput');
emit({kind:'header',case:'empty-negative',simulatedSeconds:30,hz:120,expectedSteps:3600,sourceSha256:expectedSource,checksSha256:expectedChecks,
  bootstrapSha256:sha(fileURLToPath(import.meta.url)),scope:'Read-only observations; available receiver output budget sourceWork is not emitter energy. No global conservation or live room acceptance.'});
Object.defineProperty(proto,'setInput',{...inputDescriptor,value:function(...args){const value=Reflect.apply(inputDescriptor.value,this,args);cells.add(this);return value;}});
Object.defineProperty(proto,'read',{...readDescriptor,value:function(...args){
  const observation=Reflect.apply(readDescriptor.value,this,args);cells.add(this);
  if(this.steps>(lastLogged.get(this)??0)){
    emit({kind:'completedActualStep',nativeStep:this.world.stepnumber,worldTime:this.world.time,input:{...this.input},
      observation,bodies:this.world.bodies.map(state),contacts:this.world.contacts.map(row),frictionRows:this.world.frictionEquations.map(row),
      worldConstraints:this.world.constraints.map(c=>({id:c.id,bodyA:c.bodyA.id,bodyB:c.bodyB.id,equations:c.equations.map(e=>({id:e.id,multiplier:e.multiplier,enabled:e.enabled}))}))});
    lastLogged.set(this,this.steps);completed++;
  }return observation;
}});
try{
  process.argv=[process.argv[0],checks,'--case','empty-negative'];
  await import('./prepared-checks.mjs');
}finally{
  Object.defineProperty(proto,'read',readDescriptor);Object.defineProperty(proto,'setInput',inputDescriptor);
  emit({kind:'finalBoundary',case:'empty-negative',processExitCode:process.exitCode??0,completedActualStepRecords:completed,
    observations:cells.size,sourceUnchanged:sha(source)===expectedSource,checksUnchanged:sha(checks)===expectedChecks,
    cellMethodsRestored:proto.read===readDescriptor.value&&proto.setInput===inputDescriptor.value,
    owners:[...cells].map(c=>({steps:c.steps,disposed:c.disposed,fault:c.fault,cleanupErrors:c.cleanupErrors??null,
      worldStepnumber:c.world.stepnumber,worldBodies:c.world.bodies.map(state),worldConstraints:c.world.constraints.length,
      originalCargo:state(c.cargo),ownedFinalBodies:c.bodies.map(state),lastCompletedStep:c.lastStep})),recordsBeforeFooter:records,bytesBeforeFooter:bytes});
  closeSync(fd);
}
