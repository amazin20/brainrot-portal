import sys,json,subprocess,hashlib,time,resource,threading
from pathlib import Path
base=Path(__file__).parent;case=sys.argv[1];assert case in ["math","metric","one-step"]
out=base/("actual-first-"+case);assert not out.exists();out.mkdir()
files=[p for p in base.glob("*")if p.is_file() and p.suffix in [".mjs",".md",".json"]]
freeze={str(p.name):hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
assert freeze["Room48PhaseCell.mjs"]=="73fc8dc55b288e8f693b8935f6d390e1ab94b7f28e853f013124a85384ec793a"
assert freeze["prepared-checks.mjs"]=="38d9b5e478d4c5cd70f1a35672ff0008a802875db5ed9daf9a1666ea4e8ec693"
start=time.monotonic();peak=0;samples=0;stop=threading.Event()
with (out/"stdout.json").open("wb")as stdout,(out/"stderr.txt").open("wb")as stderr:
 proc=subprocess.Popen(["timeout","10s","node","--max-old-space-size=128",str(base/"prepared-checks.mjs"),"--case",case],stdout=stdout,stderr=stderr)
 while proc.poll() is None:
  used=int(Path("/sys/fs/cgroup/memory.current").read_text());peak=max(peak,used);samples+=1
  if used>6*1024**3:proc.terminate();break
  time.sleep(.1)
 code=proc.wait(timeout=12)
post={str(p.name):hashlib.sha256(p.read_bytes()).hexdigest()for p in files};assert freeze==post
r={"case":case,"exitCode":code,"wallSeconds":time.monotonic()-start,"rssKiB":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,"globalPeakBytes":peak,"samples100ms":samples,"sourceUnchanged":True,"componentOnly":True,"allChromePreviouslyClosed":True,"wholeRoomAccepted":False,"stdoutSha256":hashlib.sha256((out/"stdout.json").read_bytes()).hexdigest()}
(out/"receipt.json").write_text(json.dumps(r,indent=2)+"\n");print(json.dumps(r));sys.exit(code)
