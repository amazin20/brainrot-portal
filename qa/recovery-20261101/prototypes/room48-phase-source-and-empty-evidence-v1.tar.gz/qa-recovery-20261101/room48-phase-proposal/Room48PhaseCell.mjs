/** NEW room48 SOURCE prototype. Not campaign code and not an execution proof.
 * Imports the exact installed primary Cannon implementation; no game starts.
 * Only setup creates owned bodies. Runtime writes are native constraint
 * vlambda/wlambda contributions and finite force queues, never solved poses.
 */
import {
  Body, Box, Constraint, ContactEquation, ContactMaterial, ConvexPolyhedron, Equation,
  FrictionEquation, GSSolver, Material, Vec3, World,
} from '../../brainrot-portal/node_modules/cannon-es/dist/cannon-es.js';

const V=(x=0,y=0,z=0)=>new Vec3(x,y,z);
const axes=['x','y','z'], EPS=1e-10;
const native={solve:GSSolver.prototype.solve,set:Vec3.prototype.set,wake:Body.prototype.wakeUp,
  gi:Equation.prototype.computeGiMGt,add:Equation.prototype.addToWlambda,gw:Equation.prototype.computeGWlambda};
const activeWorlds=new WeakSet();
const check=(ok,label)=>{if(!ok)throw Error('Room48 phase prototype: '+label);};
const finite=(v,label)=>{check(Number.isFinite(v),'finite '+label);return v;};
const array=v=>[v.x,v.y,v.z];
const dot=(a,b)=>a.x*b.x+a.y*b.y+a.z*b.z;
const sameVec=(a,b)=>axes.every(k=>Object.is(a[k],b[k]));
function slot(owner,key){const d=Object.getOwnPropertyDescriptor(owner,key);check(!d||d.configurable&&d.writable,'restorable method '+key);return{owner,key,descriptor:d,method:owner[key]};}
function put(s,method){Object.defineProperty(s.owner,s.key,{value:method,writable:true,configurable:true,enumerable:s.descriptor?.enumerable??false});}
function restore(s){if(s.descriptor)Object.defineProperty(s.owner,s.key,s.descriptor);else delete s.owner[s.key];check(s.owner[s.key]===s.method,'exact method restoration '+s.key);}
function errorMessage(error){return String(error.stack??error);}

export const ROOM48_PHASE_DESIGN=Object.freeze({
  referenceLength:35.5,measurementBase:18.2,wavelength:4,sourceWatts:80,efficiency:.4,
  forceGain:7,ratio:3,rackMass:1,doorMass:8,reflectedMass:73,inputGravity:487.5,
  trayMass:4,traySpring:62.4,trayDamping:38,traySpringAnchor:2.65,
  emptyTrayY:1.4,loadedTrayY:.4,fineMass:2,fineForce:20,fineWatts:20,fineBrake:5,
  fineRange:.3,rackSpring:27,closingDamping:9000,rackTravel:1.05,doorTravel:3.15,
  catchForce:8,catchWatts:8,catchSpring:4,catchDamping:1,catchRestX:.9,
});

/** Balanced detectors: with one arm absent their difference is exactly zero.
 * Optical transmissions are declared boundary inputs in this prototype. A
 * future live-room tracer must derive them from actual geometric light paths.
 */
export function room48PhasePower({trayY,fineQ,reference=1,measurement=1}){
  for(const[name,value]of Object.entries({trayY,fineQ,reference,measurement}))finite(value,name);
  check(reference>=0&&reference<=1&&measurement>=0&&measurement<=1,'bounded arm transmissions');
  const d=ROOM48_PHASE_DESIGN,referencePower=d.sourceWatts*reference/2,measurementPower=d.sourceWatts*measurement/2;
  const measurementLength=d.measurementBase+2*trayY+2*fineQ,delta=d.referenceLength-measurementLength;
  const difference=2*Math.sqrt(referencePower*measurementPower)*Math.cos(2*Math.PI*delta/d.wavelength);
  const total=referencePower+measurementPower;
  return{referenceLength:d.referenceLength,measurementLength,delta,referencePower,measurementPower,
    detectorPlus:(total+difference)/2,detectorMinus:(total-difference)/2,difference,
    usefulWatts:d.efficiency*Math.abs(difference),desiredForce:d.forceGain*difference};
}

/** Full spatial metric is necessary: Cannon Equation's default assumes unit
 * spatial rows, whereas the real rack link has coefficients [3,-1]. */
class LinearRow extends Equation{
  constructor(a,b,ga,gb,target){super(a,b,-1e6,1e6);this.jacobianElementA.spatial.copy(ga);this.jacobianElementB.spatial.copy(gb);this.target=target;}
  computeB(h){this.a=.2/h;this.b=1;this.eps=1e-12;return-this.a*(this.computeGq()-this.target)-this.computeGW()-h*this.computeGiMf();}
  computeGiMGt(){let sum=0;for(const[b,j]of[[this.bi,this.jacobianElementA],[this.bj,this.jacobianElementB]]){sum+=b.invMassSolve*j.spatial.lengthSquared();const r=b.invInertiaWorldSolve.vmult(j.rotational);sum+=r.dot(j.rotational);}return sum;}
}
class RowsConstraint extends Constraint{
  constructor(a,b,rows){super(a,b,{collideConnected:false});this.equations=rows;}
  update(){}
}
function wedge(){
  // Horizontal upper keeper, sloped lower entry face. A rising door pushes
  // the dog left; the falling door bears on its horizontal real upper face.
  const vertices=[[-.45,-.12,-.35],[-.45,.12,-.35],[.45,.12,-.35],[-.45,-.12,.35],[-.45,.12,.35],[.45,.12,.35]].map(p=>V(...p));
  // Native ConvexPolyhedron requires outward right-hand face winding.
  return new ConvexPolyhedron({vertices,faces:[[1,2,0],[5,4,3],[3,4,1,0],[4,5,2,1],[2,5,3,0]]});
}
function mapBodySnapshot(bodies){return bodies.map(b=>({body:b,p:b.position.clone(),v:b.velocity.clone(),w:b.angularVelocity.clone(),force:b.force.clone(),torque:b.torque.clone(),sleep:b.sleepState}));}
const translationalK=snapshot=>snapshot.reduce((n,s)=>n+.5*s.body.mass*s.v.lengthSquared(),0);

/** One provided original cargo and an owned five-body mechanism. Call
 * setInput() for ordinary bounded manual/optical input, then the normal
 * world.step(dt). read() is observation only. No world.step replacement.
 */
export class Room48PhaseCell{
  constructor(world,cargo){
    check(world instanceof World&&cargo instanceof Body&&world.bodies.includes(cargo)&&cargo.world===world,'actual native world and provided cargo');
    check(!activeWorlds.has(world),'one phase cell per world');
    check(world.solver instanceof GSSolver&&world.solver.solve===native.solve,'unmodified native GSSolver');
    check(world.gravity.x===0&&world.gravity.y===-19.5&&world.gravity.z===0,'declared gravity19.5');
    check(cargo.type===Body.DYNAMIC&&cargo.mass===3.2&&cargo.invMass===1/3.2&&cargo.shapes.length===1&&cargo.shapes[0] instanceof Box,'original3.2kg single Box');
    check(cargo.material instanceof Material,'provided actual original cargo material');
    check(axes.every(k=>cargo.shapes[0].halfExtents[k]===.39)&&cargo.shapes[0].body===cargo,'original .78m Box and owner');
    check(cargo.linearDamping===.035&&cargo.angularDamping===.16&&axes.every(k=>cargo.linearFactor[k]===1),'original damping and translation metric');
    this.world=world;this.cargo=cargo;this.original={shape:cargo.shapes[0],material:cargo.material,
      friction:cargo.material?.friction,restitution:cargo.material?.restitution,allowSleep:cargo.allowSleep,
      damping:[cargo.linearDamping,cargo.angularDamping],mask:cargo.collisionFilterMask,group:cargo.collisionFilterGroup,
      inverseInertia:cargo.invInertia.clone(),fixedRotation:cargo.fixedRotation,
      shapeOffset:cargo.shapeOffsets[0],shapeOrientation:cargo.shapeOrientations[0],offsetValues:array(cargo.shapeOffsets[0]),orientationValues:[...array(cargo.shapeOrientations[0]),cargo.shapeOrientations[0].w]};
    this.input={finePush:0,catchPush:0,reference:1,measurement:1};this.disposed=false;this.fault=null;this.lastStep=null;this.steps=0;
    this.bodies=[];this.constraints=[];this.contactMaterials=[];this.materials=[];this.projectedRows=[];
    this.sums={sourceWork:0,motorWork:0,manualWork:0,catchManualWork:0,closingHeat:0,trayDampingHeat:0,dogDampingHeat:0,fineBrakeHeat:0,
      springBackwardEulerDefect:0,forceBackwardEulerDefect:0,nativeDampingLoss:0,nativeSolverKineticDelta:0,
      appendedGearReactionWork:0,externalPreStepKineticWork:0,mechanicalResidual:0};
    try{
    const mat=(name,friction=0)=>{const m=new Material({friction,restitution:0});m.name=name;this.materials.push(m);return m;};
    this.stopMaterial=mat('48 / owned stationary machine stops');
    const make=(name,mass,position,shape,{material=mat(name),group=1,mask=8}={})=>{
      const b=new Body({mass,position:V(...position),shape,material,fixedRotation:true,allowSleep:false,
        linearDamping:0,angularDamping:0,linearFactor:V(1,1,1),collisionFilterGroup:group,collisionFilterMask:mask});
      b.name=name;this.bodies.push(b);world.addBody(b);return b;
    };
    this.anchor=make('48 / fixed guide foundation',0,[0,0,0],new Box(V(.05,.05,.05)),{material:this.stopMaterial,group:8,mask:0});
    this.tray=make('48 / actual load tray',4,[-4,1.4,0],new Box(V(.9,.12,.9)),{material:mat('48 / tray contact enamel',.9),mask:2|8});
    this.fine=make('48 / manual optical carriage',2,[-4,2.5,3],new Box(V(.18,.18,.18)));
    this.rack=make('48 / input rack',1,[-1,.25,0],new Box(V(.25,.25,.25)));
    this.door=make('48 / native three-to-one gate',8,[2,1.2,0],new Box(V(.9,1.2,.15)),{mask:2|8});
    this.dog=make('48 / sliding geometric catch',.5,[.5,2.88,0],wedge(),{group:8,mask:1});
    this.ownedDynamic=[this.tray,this.fine,this.rack,this.door,this.dog];this.measured=[cargo,...this.ownedDynamic];
    this.homes=new Map(this.ownedDynamic.map(b=>[b,b.position.clone()]));
    const stop=(name,p,half,{group=8,mask=1}={})=>make(name,0,p,new Box(V(...half)),{material:this.stopMaterial,group,mask});
    stop('48 / rack lower stop',[-1,-.1,0],[.4,.1,.4]);stop('48 / rack upper stop',[-1,1.65,0],[.4,.1,.4]);
    stop('48 / gate lower stop',[2,-.1,0],[1.1,.1,.3]);
    stop('48 / tray lower stop',[-4,.03,0],[.95,.1,.95]);stop('48 / tray upper stop',[-4,1.72,0],[.95,.1,.95]);
    stop('48 / fine negative stop',[-4-.3-.18-.08,2.5,3],[.08,.3,.3]);
    stop('48 / fine positive stop',[-4+.3+.18+.08,2.5,3],[.08,.3,.3]);
    stop('48 / catch left stop',[.15-.45-.08,2.88,0],[.08,.3,.4],{group:1,mask:8});
    stop('48 / catch right stop',[.95+.45+.08,2.88,0],[.08,.3,.4],{group:1,mask:8});
    for(const b of this.ownedDynamic){
      const free=b===this.fine||b===this.dog?'x':'y',rows=[];
      for(const axis of axes.filter(k=>k!==free)){const g=V();g[axis]=1;rows.push(new LinearRow(this.anchor,b,V(),g,b.position[axis]));}
      const c=new RowsConstraint(this.anchor,b,rows);this.constraints.push(c);world.addConstraint(c);
      const cm=new ContactMaterial(b.material,this.stopMaterial,{friction:0,restitution:0,contactEquationStiffness:1e9,contactEquationRelaxation:4});this.contactMaterials.push(cm);world.addContactMaterial(cm);
    }
    this.gear=new RowsConstraint(this.rack,this.door,[new LinearRow(this.rack,this.door,V(0,3,0),V(0,-1,0),3*.25-1.2)]);
    this.constraints.push(this.gear);world.addConstraint(this.gear);
    const trayPair=new ContactMaterial(cargo.material,this.tray.material,{friction:.9,restitution:0,contactEquationStiffness:1e8,contactEquationRelaxation:4});this.contactMaterials.push(trayPair);world.addContactMaterial(trayPair);
    this.ownedRecords=this.bodies.map(b=>({body:b,mass:b.mass,type:b.type,material:b.material,group:b.collisionFilterGroup,mask:b.collisionFilterMask,shape:b.shapes[0],
      half:b.shapes[0].halfExtents?.clone()??null,vertices:b.shapes[0].vertices?.map(v=>v.clone())??null,faces:b.shapes[0].faces?.map(f=>[...f])??null,position:b.position.clone()}));
    this.solveSlot=slot(world.solver,'solve');this.solveWrapper=(h,w)=>this._solve(h,w);put(this.solveSlot,this.solveWrapper);
    this.pre=()=>{try{return this._preStep();}catch(error){this.fault=errorMessage(error);throw error;}};
    this.post=()=>{try{return this._postStep();}catch(error){this.fault=errorMessage(error);throw error;}};
    world.addEventListener('preStep',this.pre);this.recordedPre=world._listeners.preStep;
    world.addEventListener('postStep',this.post);this.recordedPost=world._listeners.postStep;
    this.recordedPost.splice(this.recordedPost.indexOf(this.post),1);this.recordedPost.unshift(this.post);
    this.preInventory=[...this.recordedPre];this.postInventory=[...this.recordedPost];
    activeWorlds.add(world);this._owners();
    }catch(error){let cleanup=null;try{this.dispose();}catch(e){cleanup=e;}throw Error(errorMessage(error)+(cleanup?'\nPartial setup cleanup: '+errorMessage(cleanup):''));}
  }
  _owners(){
    check(!this.disposed&&!this.fault,'live unfaulted owner');const{world:w,cargo:b,original:o}=this;
    check(w.gravity.x===0&&w.gravity.y===-19.5&&w.gravity.z===0,'declared gravity retained');
    check(b.world===w&&w.bodies.includes(b)&&b.type===Body.DYNAMIC&&b.mass===3.2&&b.invMass===1/3.2&&sameVec(b.invInertia,o.inverseInertia)&&b.fixedRotation===o.fixedRotation&&b.shapes.length===1&&b.shapes[0]===o.shape&&o.shape.body===b,'original physical cargo retained');
    check(axes.every(k=>o.shape.halfExtents[k]===.39)&&b.material===o.material&&b.material.friction===o.friction&&b.material.restitution===o.restitution,'original shape/material retained');
    check(b.linearDamping===.035&&b.angularDamping===.16&&b.collisionFilterGroup===o.group,'original damping and collision group retained');
    // Production pickup/release legitimately changes these two controls. This
    // component neither writes them nor turns their values into a power gate.
    check(typeof b.allowSleep==='boolean'&&[1,5].includes(b.collisionFilterMask),'ordinary cargo sleep/filter control states');
    check(b.shapeOffsets[0]===o.shapeOffset&&b.shapeOrientations[0]===o.shapeOrientation&&axes.every((k,i)=>Object.is(o.shapeOffset[k],o.offsetValues[i])&&Object.is(o.shapeOrientation[k],o.orientationValues[i]))&&Object.is(o.shapeOrientation.w,o.orientationValues[3])&&axes.every(k=>b.linearFactor[k]===1),'original shape transform/translation metric');
    check(w.solver===this.solveSlot.owner&&w.solver.solve===this.solveWrapper,'owned solver observer');
    check(w._listeners.preStep===this.recordedPre&&w._listeners.postStep===this.recordedPost&&this.recordedPre.length===this.preInventory.length&&this.recordedPre.every((f,i)=>f===this.preInventory[i])&&this.recordedPost.length===this.postInventory.length&&this.recordedPost.every((f,i)=>f===this.postInventory[i]),'fixed listener ordering');
    check(this.recordedPre.at(-1)===this.pre&&this.recordedPost[0]===this.post,'LAST preStep and FIRST postStep');
    for(const body of this.ownedDynamic)check(body.world===w&&w.bodies.includes(body)&&body.mass>0&&body.invMass===1/body.mass&&body.fixedRotation&&!body.allowSleep&&body.sleepState!==Body.SLEEPING&&body.invInertia.lengthSquared()===0&&body.invInertiaWorld.elements.every(v=>v===0)&&body.linearDamping===0&&body.angularDamping===0&&axes.every(k=>body.linearFactor[k]===1),'owned awake native guide body metric');
    for(const r of this.ownedRecords){const b=r.body;check(b.world===w&&w.bodies.includes(b)&&b.mass===r.mass&&b.type===r.type&&b.material===r.material&&b.collisionFilterGroup===r.group&&b.collisionFilterMask===r.mask&&b.shapes.length===1&&b.shapes[0]===r.shape&&r.shape.body===b,'owned actual body/shape/material identities');check(b.quaternion.x===0&&b.quaternion.y===0&&b.quaternion.z===0&&b.quaternion.w===1&&b.angularVelocity.lengthSquared()===0,'fixed-orientation guide model');if(r.half)check(sameVec(r.shape.halfExtents,r.half),'owned original Box geometry');if(r.vertices)check(r.shape.vertices.length===r.vertices.length&&r.vertices.every((v,i)=>sameVec(r.shape.vertices[i],v))&&r.faces.every((f,i)=>f.length===r.shape.faces[i].length&&f.every((v,j)=>v===r.shape.faces[i][j])),'owned actual catch geometry');if(b.type===Body.STATIC)check(sameVec(b.position,r.position),'actual fixed stop location');}
    for(const c of this.constraints)check(w.constraints.includes(c),'owned native constraint remains registered');
  }
  setInput({finePush=0,catchPush=0,reference=1,measurement=1}={}){
    this._owners();for(const[k,v]of Object.entries({finePush,catchPush,reference,measurement}))finite(v,k);
    check(finePush>=-1&&finePush<=1&&catchPush>=-1&&catchPush<=1&&reference>=0&&reference<=1&&measurement>=0&&measurement<=1,'ordinary bounded input');
    this.input={finePush,catchPush,reference,measurement};
  }
  _response(eq){
    for(const b of this.ownedDynamic)check(b.invMassSolve===1/b.mass,'actual native awake solve inverse mass');
    const jac=new Map();for(const[b,j]of[[eq.bi,eq.jacobianElementA],[eq.bj,eq.jacobianElementB]])jac.set(b,{linear:j.spatial.clone(),angular:j.rotational.clone()});
    const response=new Map();let r=jac.get(this.rack)?.linear.y??0,d=jac.get(this.door)?.linear.y??0;
    for(const[b,j]of jac){let linear=j.linear.scale(b.invMassSolve),angular=b.invInertiaWorldSolve.vmult(j.angular);
      if(b===this.tray)linear=V(0,j.linear.y*b.invMassSolve,0);
      if(b===this.fine||b===this.dog)linear=V(j.linear.x*b.invMassSolve,0,0);
      if(this.ownedDynamic.includes(b))angular=V();response.set(b,{linear,angular});
    }
    if(jac.has(this.rack)||jac.has(this.door)){const u=(r+3*d)/73;response.set(this.rack,{linear:V(0,u,0),angular:V()});response.set(this.door,{linear:V(0,3*u,0),angular:V()});}
    let metric=0;for(const[b,j]of jac){const v=response.get(b);metric+=j.linear.dot(v.linear)+j.angular.dot(v.angular);}
    check(Number.isFinite(metric)&&metric>=-1e-12,'nonnegative projected actual contact metric');return{jac,response,metric:Math.max(0,metric)};
  }
  _solve(h,w){
    this._owners();check(w===this.world&&h>0&&h<=1/60,'actual bounded native solve');
    this.beforeSolve=mapBodySnapshot(this.measured);this.contactReaction=new Map();this.contactRows=0;this.redundantRows=0;this.wokeOriginalContact=false;
    // An awake dynamic support cannot drop its load merely because Cannon
    // made the original supported cargo static for sleep. This is the native
    // wake API on an actual enabled contact, not an optical loaded predicate.
    if(this.cargo.sleepState===Body.SLEEPING&&w.contacts.some(c=>c.enabled&&this.ownedDynamic.some(b=>(c.bi===this.cargo&&c.bj===b)||(c.bj===this.cargo&&c.bi===b)))){native.wake.call(this.cargo);this.wokeOriginalContact=true;}
    const rows=new Set([...w.contacts,...w.frictionEquations]);let primary=null,value;
    try{
      for(const eq of w.solver.equations){if(!rows.has(eq)||!this.ownedDynamic.some(b=>eq.bi===b||eq.bj===b))continue;
        const gi=slot(eq,'computeGiMGt'),add=slot(eq,'addToWlambda'),rhs=slot(eq,'computeB'),gw=slot(eq,'computeGWlambda');check(gi.method===native.gi&&add.method===native.add&&gw.method===native.gw&&(rhs.method===ContactEquation.prototype.computeB||rhs.method===FrictionEquation.prototype.computeB),'unmodified actual pooled contact methods');
        let plan=null;put(rhs,h=>{const value=rhs.method.call(eq,h);plan=this._response(eq);if(plan.metric>EPS)return value;
          // A zero-response row is algebraically redundant with the owned
          // native guides. It cannot repair incompatible penetration.
          if(eq instanceof ContactEquation){const gap=eq.ni.dot(eq.bj.position.vadd(eq.rj).vsub(eq.bi.position).vsub(eq.ri));check(gap>=-5e-5,'incompatible fully blocked physical contact');}
          this.redundantRows++;return 0;});this.projectedRows.push(rhs);
        put(gw,()=>plan&&plan.metric<=EPS?0:gw.method.call(eq));this.projectedRows.push(gw);
        put(gi,()=>{check(plan,'native computeB precedes projected metric');return plan.metric;});this.projectedRows.push(gi);
        put(add,delta=>{check(plan&&Number.isFinite(delta),'native projected increment');for(const[b,r]of plan.response){b.vlambda.addScaledVector(delta,r.linear,b.vlambda);b.wlambda.addScaledVector(delta,r.angular,b.wlambda);if(this.ownedDynamic.includes(b)){const raw=plan.jac.get(b)?.linear??V(),reaction=r.linear.scale(b.mass).vsub(raw).scale(delta),sum=this.contactReaction.get(b)??V();sum.vadd(reaction,sum);this.contactReaction.set(b,sum);}}});this.projectedRows.push(add);this.contactRows++;
      }
      value=this.solveSlot.method.call(w.solver,h,w);
    }catch(error){primary=error;}
    const errors=[];for(const s of this.projectedRows.splice(0).reverse())try{restore(s);}catch(e){errors.push(errorMessage(e));}
    if(primary||errors.length){this.fault=errorMessage(primary??Error(errors.join('; ')));throw Error(this.fault+(errors.length?'; restoration: '+errors.join('; '):''));}
    this.afterSolve=mapBodySnapshot(this.measured);return value;
  }
  _preStep(){
    this._owners();const w=this.world,h=w.dt;check(this.beforeSolve&&this.afterSolve&&h>0&&h<=1/60,'actual preStep after native solve');
    const pre=mapBodySnapshot(this.measured),force=new Map(this.ownedDynamic.map(b=>[b,b.force.clone()])),d=ROOM48_PHASE_DESIGN;
    for(let i=0;i<pre.length;i++)check(sameVec(pre[i].p,this.beforeSolve[i].p),'no foreign preStep pose resynchronization');
    const pending=(b,axis)=>b.velocity[axis]+h*b.force[axis]/b.mass;
    const bounded=(wanted,power,velocity)=>{if(wanted*velocity(wanted)<=power)return wanted;let lo=0,hi=1;for(let i=0;i<60;i++){const t=(lo+hi)/2;if(wanted*t*velocity(wanted*t)<=power*(1-1e-12))lo=t;else hi=t;}return wanted*lo;};
    const trayV=(pending(this.tray,'y')-h*d.traySpring*(this.tray.position.y-d.traySpringAnchor)/4)/(1+h*d.trayDamping/4+h*h*d.traySpring/4);
    const traySpring=-d.traySpring*(this.tray.position.y+h*trayV-d.traySpringAnchor),trayDamp=-d.trayDamping*trayV;force.get(this.tray).y+=traySpring+trayDamp;
    const dogEnd=f=>(pending(this.dog,'x')+h*(f-d.catchSpring*(this.dog.position.x-d.catchRestX))/.5)/(1+h*d.catchDamping/.5+h*h*d.catchSpring/.5);
    const catchForce=bounded(d.catchForce*this.input.catchPush,d.catchWatts,dogEnd),dogV=dogEnd(catchForce),dogSpring=-d.catchSpring*(this.dog.position.x+h*dogV-d.catchRestX),dogDamp=-d.catchDamping*dogV;force.get(this.dog).x+=catchForce+dogSpring+dogDamp;
    const fineFree=pending(this.fine,'x'),fineCommand=d.fineForce*this.input.finePush;
    const fineEnd=f=>{const v=fineFree+h*f/2;return Math.sign(v)*Math.max(0,Math.abs(v)-h*d.fineBrake/2);};
    const fineForce=bounded(fineCommand,d.fineWatts,fineEnd),fineV=fineEnd(fineForce),fineBrake=2*(fineV-fineFree)/h-fineForce;force.get(this.fine).x+=fineForce+fineBrake;
    const optics=room48PhasePower({trayY:this.tray.position.y,fineQ:this.fine.position.x+4,...this.input});
    const q=this.rack.position.y-.25,rackFree=pending(this.rack,'y');
    const rackEnd=f=>{const numerator=rackFree+h*(f-d.rackSpring*q)/73,denominator=1+h*h*d.rackSpring/73+(numerator<0?h*d.closingDamping/73:0);return numerator/denominator;};
    const motor=bounded(optics.desiredForce,optics.usefulWatts,rackEnd),rackV=rackEnd(motor),rackSpring=-d.rackSpring*(q+h*rackV),closer=-d.closingDamping*Math.min(rackV,0),rawRack=motor+rackSpring+closer;
    // Raw force acts on the rack; ideal gear reaction is explicit. Existing
    // pending forces are untouched: native H rows already compensated them.
    force.get(this.rack).y+=rawRack/73;force.get(this.door).y+=24*rawRack/73;
    for(const[b,f]of force){for(const k of axes){const desc=Object.getOwnPropertyDescriptor(b.force,k);check(desc?.writable&&Number.isFinite(f[k]),'atomic finite writable force queue');}check(b.force instanceof Vec3&&b.force.set===native.set,'native force vector owner');}
    this.stepPlan={h,stepBefore:w.stepnumber,pre,beforeSolve:this.beforeSolve,afterSolve:this.afterSolve,force,pressure:optics,
      predicted:{trayV,dogV,fineV,rackV},forces:{traySpring,trayDamp,catchForce,dogSpring,dogDamp,fineForce,fineBrake,motor,rackSpring,closer,rawRack},
      q0:q,tray0:this.tray.position.y,dog0:this.dog.position.x,fine0:this.fine.position.x};
    for(const[b,f]of force)native.set.call(b.force,f.x,f.y,f.z);
  }
  _postStep(){
    this._owners();const p=this.stepPlan,w=this.world;check(p&&w.stepnumber===p.stepBefore+1,'one actual native integration');const end=mapBodySnapshot(this.measured),by=new Map(end.map(s=>[s.body,s]));
    const delta=(b,axis)=>b.position[axis]-p.pre.find(s=>s.body===b).p[axis],f=p.forces,h=p.h,dy=delta(this.rack,'y'),dd=delta(this.door,'y'),dt=delta(this.tray,'y'),dx=delta(this.fine,'x'),dg=delta(this.dog,'x');
    const motorWork=f.motor*dy,manualWork=f.fineForce*dx,catchManualWork=f.catchForce*dg,sourceWork=p.pressure.usefulWatts*h;
    check(motorWork<=sourceWork+1e-8,'actual raw motor port work within optical power');check(manualWork<=ROOM48_PHASE_DESIGN.fineWatts*h+1e-8,'actual manual port work within20W');
    check(catchManualWork<=ROOM48_PHASE_DESIGN.catchWatts*h+1e-8,'actual catch manual port work within8W');
    const heat={closing:-f.closer*dy,tray:-f.trayDamp*dt,dog:-f.dogDamp*dg,fine:-f.fineBrake*dx};for(const[k,v]of Object.entries(heat))check(v>=-1e-8,'actual nonnegative physical '+k+' dissipation');
    const work=new Map();let allForceWork=0,beForce=0,pendingWork=0,nativeDamp=0,externalPreStepKineticWork=0;
    for(let i=0;i<end.length;i++){const s=end[i],before=p.pre[i],total=p.force.get(s.body)??before.force,dp=s.p.vsub(before.p),value=total.dot(dp);work.set(s.body,value);allForceWork+=value;pendingWork+=before.force.dot(dp);beForce+=.5*s.body.mass*s.v.vsub(before.v).lengthSquared();const solved=p.afterSolve[i],damped=solved.v.scale((1-s.body.linearDamping)**h);nativeDamp+=.5*s.body.mass*(solved.v.lengthSquared()-damped.lengthSquared());externalPreStepKineticWork+=.5*s.body.mass*(before.v.lengthSquared()-damped.lengthSquared());}
    const solverDelta=translationalK(p.afterSolve)-translationalK(p.beforeSolve),deltaK=translationalK(end)-translationalK(p.beforeSolve);
    const genericIdentity=deltaK-solverDelta+nativeDamp-externalPreStepKineticWork-allForceWork+beForce;
    check(Math.abs(genericIdentity)<1e-6,'measured native translational integration identity');
    const reactionWork=(-72*f.rawRack/73)*dy+(24*f.rawRack/73)*dd;
    const springBE=.5*62.4*dt*dt+.5*27*dy*dy+.5*4*dg*dg;
    const positionError=3*(this.rack.position.y-.25)-(this.door.position.y-1.2),velocityError=3*this.rack.velocity.y-this.door.velocity.y;
    const field={trayY:this.tray.position.y,fineQ:this.fine.position.x+4,rackQ:this.rack.position.y-.25,doorClearance:this.door.position.y-1.2,dogX:this.dog.position.x};
    const cargoContact=w.contacts.filter(c=>c.enabled&&((c.bi===this.cargo&&c.bj===this.tray)||(c.bj===this.cargo&&c.bi===this.tray))).map(c=>({bodyA:c.bi.id,bodyB:c.bj.id,shapeA:c.si?.id,shapeB:c.sj?.id,multiplier:c.multiplier,upwardNormal:c.bi===this.cargo?-c.ni.y:c.ni.y}));
    this.lastStep={step:w.stepnumber,dt:h,field,optics:p.pressure,forces:{...f},motorWork,sourceWork,manualWork,catchManualWork,heat,springBackwardEulerDefect:springBE,forceBackwardEulerDefect:beForce,nativeDampingLoss:nativeDamp,nativeSolverKineticDelta:solverDelta,externalPreStepKineticWork,pendingForceWork:pendingWork,allForceWork,appendedGearReactionWork:reactionWork,nativeTranslationalResidual:genericIdentity,gear:{positionError,velocityError},projectedContactRows:this.contactRows,redundantOwnedRows:this.redundantRows,projectedContactReactionImpulses:[...this.contactReaction].map(([b,v])=>({body:b.name,impulse:array(v)})),cargoTrayContacts:cargoContact,wokeActualCargoContact:this.wokeOriginalContact,originalCargo:{id:this.cargo.id,shapeId:this.original.shape.id,mass:this.cargo.mass,half:array(this.original.shape.halfExtents),allowSleep:this.cargo.allowSleep,sleepState:this.cargo.sleepState},scope:'Native Cannon translation and physical port work. Signed solver/constraint stabilization is not heat; rotational/global/full-room conservation is not asserted.'};
    for(const[k,v]of Object.entries({sourceWork,motorWork,manualWork,catchManualWork,closingHeat:heat.closing,trayDampingHeat:heat.tray,dogDampingHeat:heat.dog,fineBrakeHeat:heat.fine,springBackwardEulerDefect:springBE,forceBackwardEulerDefect:beForce,nativeDampingLoss:nativeDamp,nativeSolverKineticDelta:solverDelta,externalPreStepKineticWork,appendedGearReactionWork:reactionWork,mechanicalResidual:genericIdentity}))this.sums[k]+=v;
    this.integrationSnapshot=end;this.steps++;this.stepPlan=null;
  }
  read(){
    this._owners();if(this.integrationSnapshot){for(const s of this.integrationSnapshot){check(sameVec(s.body.position,s.p),'postStep/final boundary position unchanged');if(s.body===this.cargo&&s.body.sleepState===Body.SLEEPING){check(s.body.velocity.lengthSquared()===0,'native sleeping cargo velocity');}else check(sameVec(s.body.velocity,s.v),'postStep/final boundary velocity unchanged');}}
    const nativeSleeping=this.cargo.sleepState===Body.SLEEPING,sleepStart=this.integrationSnapshot?.find(s=>s.body===this.cargo);
    const nativeSleepRemovedTranslationalKinetic=nativeSleeping&&sleepStart&&sleepStart.sleep!==Body.SLEEPING ? .5*this.cargo.mass*sleepStart.v.lengthSquared() : 0;
    return{steps:this.steps,lastStep:this.lastStep,sums:{...this.sums},nativeSleepBoundaryObserved:nativeSleeping,nativeSleepRemovedTranslationalKinetic,originalOwnersPreserved:true,worldBodies:this.world.bodies.length,worldConstraints:this.world.constraints.length,wholeRoomAccepted:false,scope:'NEW unintegrated phase/native-gear component; post-integration ledger precedes native sleep, whose observed translational removal is separate. No GLB, portal, held-cargo or whole-campaign acceptance.'};
  }
  dispose(){
    if(this.disposed)return;const errors=[];const attempt=(name,fn)=>{try{fn();}catch(e){errors.push(name+': '+errorMessage(e));}};
    for(const s of this.projectedRows.splice(0).reverse())attempt('pooled row restoration',()=>restore(s));
    if(this.solveSlot)attempt('solver restoration',()=>{check(this.world.solver===this.solveSlot.owner,'original solver owner');if(this.world.solver.solve===this.solveWrapper)restore(this.solveSlot);else check(this.world.solver.solve===this.solveSlot.method,'restore only owned solver slot');});
    for(const[name,fn,old]of[['preStep',this.pre,this.recordedPre],['postStep',this.post,this.recordedPost]])for(const list of new Set([old,this.world._listeners?.[name]].filter(Boolean)))attempt('remove owned '+name,()=>{for(let i=list.length-1;i>=0;i--)if(list[i]===fn)list.splice(i,1);});
    for(const c of this.constraints)attempt('remove owned constraint',()=>{if(this.world.constraints.includes(c))this.world.removeConstraint(c);});
    for(const b of this.bodies)attempt('remove owned body',()=>{if(this.world.bodies.includes(b))this.world.removeBody(b);});
    for(const cm of this.contactMaterials)attempt('remove owned contact pair',()=>{if(this.world.contactmaterials.includes(cm))this.world.removeContactMaterial(cm);});
    activeWorlds.delete(this.world);this.disposed=true;this.cleanupErrors=errors;
    check(this.cargo.world===this.world&&this.world.bodies.includes(this.cargo)&&this.cargo.shapes[0]===this.original.shape,'dispose retains original cargo');
    if(errors.length)throw Error(errors.join('; '));
  }
}
