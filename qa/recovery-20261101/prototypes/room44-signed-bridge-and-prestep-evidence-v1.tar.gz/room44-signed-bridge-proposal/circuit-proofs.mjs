/** SOURCE ONLY: no execution receipt exists for this NEW reconstruction.
 * These tests invoke no browser, game, Cannon World, build or network.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {Room44SignedBridgeCircuit, solveRoom44SignedBridge,
  ROOM44_CORRECT_DIODE_PORTS, ROOM44_SWAPPED_AC_DC_DIODE_PORTS} from './Room44SignedBridgeCircuit.mjs';

const close = (actual, expected, tolerance = 1e-9) => assert.ok(Math.abs(actual - expected) <= tolerance,
  `Expected ${actual} to be within ${tolerance} of ${expected}`);
function checkStep(result) {
  const {parameters: p, nodeVoltages: v, ledger: e} = result;
  close(v.N, 0, 1e-12);
  close(v.A - v.B, result.emf - p.generatorResistance * result.generatorCurrent);
  close(v[p.motorPorts[0]] - v[p.motorPorts[1]], result.motorEmf + p.motorResistance * result.motorCurrent);
  close(result.capacitorCurrent, p.capacitance * (result.voltage - result.previousVoltage) / result.dt);
  close(result.generatorForce * result.generatorVelocity * result.dt, -e.generatorWork);
  close(result.motorForce * result.motorVelocity * result.dt, e.motorWork);
  for (let i = 0; i < 4; i++) {
    const d = p.diodes[i], current = result.diodeCurrents[i];
    assert.ok(current >= 0, 'Every real diode blocks reverse current');
    close(current, Math.max(0, (v[d.ports[0]] - v[d.ports[1]] - d.drop) / d.resistance), 1e-8);
  }
  for (const residual of Object.values(result.kcl)) close(residual, 0, 1e-8);
  for (const key of ['generatorHeat', 'motorHeat', 'diodeHeat', 'capacitorBackwardEulerDefect']) assert.ok(e[key] >= 0);
  close(e.generatorWork, e.motorWork + e.storedDelta + e.generatorHeat + e.motorHeat + e.diodeHeat + e.capacitorBackwardEulerDefect, 2e-8);
  assert.equal(result.gauges.injectedCurrent, 0); assert.equal(result.gauges.dissipatedWork, 0);
}

test('Both signed generator directions select their actual complementary diode paths', () => {
  const plus = solveRoom44SignedBridge({dt: 1 / 120, generatorVelocity: 6});
  const minus = solveRoom44SignedBridge({dt: 1 / 120, generatorVelocity: -6});
  checkStep(plus); checkStep(minus);
  assert.ok(plus.generatorCurrent > 0 && minus.generatorCurrent < 0);
  assert.ok(plus.voltage > 0 && minus.voltage > 0);
  assert.deepEqual(plus.diodeCurrents.map(i => i > 1e-10), [true, false, false, true]);
  assert.deepEqual(minus.diodeCurrents.map(i => i > 1e-10), [false, true, true, false]);
  close(plus.voltage, minus.voltage); close(plus.generatorCurrent, -minus.generatorCurrent);
  assert.ok(plus.generatorForce < 0 && minus.generatorForce > 0);
});

test('Swapping the real AC/DC branch graph cannot rectify either source sign into an empty output', () => {
  for (const velocity of [-9, -2, 0, 2, 9]) {
    const r = solveRoom44SignedBridge({parameters: {diodes: ROOM44_SWAPPED_AC_DC_DIODE_PORTS}, dt: 1 / 120, generatorVelocity: velocity});
    checkStep(r); close(r.voltage, 0, 1e-9); close(r.motorCurrent, 0, 1e-9);
    assert.deepEqual(r.parameters.diodes.map(d => [...d.ports]), ROOM44_SWAPPED_AC_DC_DIODE_PORTS);
  }
});

test('Reversing actual motor terminals reverses force with the same charged source', () => {
  const a = solveRoom44SignedBridge({dt: 1 / 120, voltage: 8, generatorVelocity: 0});
  const b = solveRoom44SignedBridge({parameters: {motorPorts: ['N', 'P']}, dt: 1 / 120, voltage: 8, generatorVelocity: 0});
  checkStep(a); checkStep(b); assert.ok(a.motorForce > 0 && b.motorForce < 0);
  close(a.voltage, b.voltage); close(a.motorForce, -b.motorForce);
});

test('A charged capacitor drives the motor while all source diodes are genuinely off', () => {
  const r = solveRoom44SignedBridge({dt: 1 / 120, voltage: 8, generatorVelocity: 0});
  checkStep(r); assert.equal(r.mask, 0); assert.equal(r.gauges.components.length, 2);
  close(r.generatorCurrent, 0); assert.ok(r.diodeCurrents.every(i => i === 0));
  close(r.voltage, 8 / (1 + r.dt / (r.parameters.motorResistance * r.parameters.capacitance)));
  assert.ok(r.ledger.storedDelta < 0 && r.ledger.motorHeat > 0);
});

test('Motor backdrive charges storage with negative signed mechanical output work', () => {
  const r = solveRoom44SignedBridge({dt: 1 / 120, voltage: 3, generatorVelocity: 0, motorVelocity: 5});
  checkStep(r); assert.ok(r.motorCurrent < 0 && r.motorForce < 0);
  assert.ok(r.ledger.motorWork < 0 && r.ledger.storedDelta > 0); close(r.ledger.generatorWork, 0);
});

test('Unequal actual diode drops and resistances preserve KCL and the physical work identity', () => {
  const diodeBranches = ROOM44_CORRECT_DIODE_PORTS.map((ports, i) => ({ports, drop: .1 + i * .07, resistance: .03 + i * .04}));
  for (const generatorVelocity of [-7, -.1, 0, .1, 7]) checkStep(solveRoom44SignedBridge({
    parameters: {diodes: diodeBranches}, dt: 1 / 240, voltage: 1.5, generatorVelocity, motorVelocity: -.4,
  }));
});

test('A signed waveform preserves accumulated work with physical heat and BE defect kept separate', () => {
  const circuit = new Room44SignedBridgeCircuit(), initial = circuit.snapshot();
  for (let i = 0; i < 240; i++) {
    const r = circuit.step(1 / 120, {generatorVelocity: 6 * Math.sin(i * Math.PI / 30), motorVelocity: .25 * Math.sin(i * .09)});
    checkStep(r);
  }
  const final = circuit.snapshot(), e = final.ledger;
  close(final.storedEnergy - initial.storedEnergy, e.storedDelta, 2e-8);
  close(e.generatorWork, e.motorWork + e.storedDelta + e.generatorHeat + e.motorHeat + e.diodeHeat + e.capacitorBackwardEulerDefect, 2e-7);
  assert.ok(e.generatorHeat > 0 && e.motorHeat > 0 && e.diodeHeat > 0 && e.capacitorBackwardEulerDefect > 0);
  assert.equal(final.steps, 240);
});

test('Deterministic varied circuit parameters remain complementary without wiring-valid multipliers', () => {
  let seed = 0x44123;
  const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 2 ** 32; };
  for (let i = 0; i < 512; i++) {
    const p = {generatorConstant: 1 + 7 * random(), generatorResistance: .1 + 2 * random(),
      capacitance: .2 + 3 * random(), motorConstant: 1 + 9 * random(), motorResistance: .3 + 5 * random(),
      diodeDrop: .05 + .7 * random(), diodeResistance: .02 + .3 * random(),
      motorPorts: i % 3 ? ['P', 'N'] : ['N', 'P'],
      diodes: i % 5 ? ROOM44_CORRECT_DIODE_PORTS : ROOM44_SWAPPED_AC_DC_DIODE_PORTS};
    checkStep(solveRoom44SignedBridge({parameters: p, dt: i % 2 ? 1 / 120 : 1 / 240,
      voltage: -2 + random() * 15, generatorVelocity: -10 + random() * 20, motorVelocity: -3 + random() * 6}));
  }
});

test('Invalid input and overflow fail before any electrical state commit', () => {
  const c = new Room44SignedBridgeCircuit({initialVoltage: 4}), before = c.snapshot();
  for (const action of [() => c.step(0), () => c.step(-.1), () => c.step(NaN),
    () => c.step(1 / 120, {generatorVelocity: Infinity}), () => c.step(1 / 120, {motorVelocity: NaN}),
    () => c.step(Number.MIN_VALUE)]) {
    assert.throws(action); assert.deepEqual(c.snapshot(), before);
  }
  for (const options of [{capacitance: 0}, {motorResistance: -1}, {generatorResistance: Infinity},
    {diodeDrop: -.1}, {diodes: [['A', 'A']]}, {motorPorts: ['P', 'P']}, {initialVoltage: Number.MAX_VALUE}])
    assert.throws(() => new Room44SignedBridgeCircuit(options));
  for (const [options, inputs] of [
    [{motorConstant: 1e308, initialVoltage: 8}, {generatorVelocity: 0, motorVelocity: 0}],
    [{generatorConstant: 1e308}, {generatorVelocity: 3e-308, motorVelocity: 0}],
  ]) {
    const huge = new Room44SignedBridgeCircuit(options), initial = huge.snapshot();
    assert.throws(() => huge.step(1 / 120, inputs), 'Unrepresentable actual force must reject the step');
    assert.deepEqual(huge.snapshot(), initial, 'Force overflow must precede every state commit');
  }
});

test('Zero-power gauges add no leaky load or hidden energy source', () => {
  const c = new Room44SignedBridgeCircuit({initialVoltage: 0});
  for (let i = 0; i < 120; i++) {
    const r = c.step(1 / 120); checkStep(r);
    for (const current of [...r.diodeCurrents, r.generatorCurrent, r.motorCurrent, r.capacitorCurrent]) close(current, 0, 1e-12);
    for (const value of Object.values(r.ledger)) close(value, 0, 1e-12);
  }
  close(c.snapshot().storedEnergy, 0, 1e-12);
});
