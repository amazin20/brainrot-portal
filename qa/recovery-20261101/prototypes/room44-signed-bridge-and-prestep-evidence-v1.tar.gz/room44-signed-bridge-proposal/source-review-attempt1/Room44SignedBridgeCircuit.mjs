/** NEW reconstruction, SOURCE ONLY until a separate execution receipt exists.
 * Four actual diode branches and signed generator/motor ports. This module
 * starts no simulation, browser, route or build. It owns no Cannon bodies.
 */
const NODES = Object.freeze(['A', 'B', 'P', 'N']);
const NODE = new Map(NODES.map((name, index) => [name, index]));
const correctBridge = Object.freeze([
  Object.freeze(['A', 'P']), Object.freeze(['B', 'P']),
  Object.freeze(['N', 'A']), Object.freeze(['N', 'B']),
]);
export const ROOM44_CORRECT_DIODE_PORTS = correctBridge;
export const ROOM44_SWAPPED_AC_DC_DIODE_PORTS = Object.freeze([
  Object.freeze(['P', 'A']), Object.freeze(['N', 'A']),
  Object.freeze(['B', 'P']), Object.freeze(['B', 'N']),
]);

const finite = (value, name) => {
  if (!Number.isFinite(value)) throw new TypeError('Finite ' + name + ' required');
  return value;
};
const positive = (value, name) => {
  finite(value, name);
  if (!(value > 0)) throw new RangeError('Positive ' + name + ' required');
  return value;
};
function ports(value, name) {
  if (!Array.isArray(value) || value.length !== 2 || value.some(n => !NODE.has(n)) || value[0] === value[1])
    throw new TypeError('Two distinct actual node names required for ' + name);
  return Object.freeze([...value]);
}
function parameters(input = {}) {
  const p = {
    generatorConstant: positive(input.generatorConstant ?? 4, 'generator constant'),
    generatorResistance: positive(input.generatorResistance ?? .7, 'generator resistance'),
    capacitance: positive(input.capacitance ?? 1.5, 'capacitance'),
    motorConstant: positive(input.motorConstant ?? 6, 'motor constant'),
    motorResistance: positive(input.motorResistance ?? 3, 'motor resistance'),
    motorPorts: ports(input.motorPorts ?? ['P', 'N'], 'motor'),
  };
  const drop = finite(input.diodeDrop ?? .25, 'diode drop');
  if (drop < 0) throw new RangeError('Nonnegative diode drop required');
  const resistance = positive(input.diodeResistance ?? .08, 'diode resistance');
  const supplied = input.diodes ?? correctBridge;
  if (!Array.isArray(supplied) || supplied.length !== 4) throw new TypeError('Exactly four diode branches required');
  p.diodes = Object.freeze(supplied.map((branch, i) => {
    const pair = ports(Array.isArray(branch) ? branch : branch?.ports, 'diode ' + i);
    const vf = finite(Array.isArray(branch) ? drop : branch.drop ?? drop, 'diode forward drop');
    if (vf < 0) throw new RangeError('Nonnegative diode forward drop required');
    return Object.freeze({ports: pair, drop: vf,
      resistance: positive(Array.isArray(branch) ? resistance : branch.resistance ?? resistance, 'diode resistance')});
  }));
  return Object.freeze(p);
}

/** Small dense solve with scaled partial pivoting. A failed/ill-conditioned
 * active set is rejected; no artificial conductance or current is introduced. */
function solveLinear(matrix, right) {
  const a = matrix.map((row, i) => [...row, right[i]]), n = a.length;
  const scale = a.map(row => Math.max(...row.slice(0, n).map(Math.abs)));
  for (let col = 0; col < n; col++) {
    let pivot = col, score = -1;
    for (let row = col; row < n; row++) {
      const candidate = scale[row] ? Math.abs(a[row][col]) / scale[row] : 0;
      if (candidate > score) { score = candidate; pivot = row; }
    }
    if (!(score > 1e-14)) return null;
    [a[col], a[pivot]] = [a[pivot], a[col]];
    [scale[col], scale[pivot]] = [scale[pivot], scale[col]];
    for (let row = col + 1; row < n; row++) {
      const factor = a[row][col] / a[col][col];
      a[row][col] = 0;
      for (let k = col + 1; k <= n; k++) a[row][k] -= factor * a[col][k];
    }
  }
  const x = new Array(n).fill(0);
  for (let row = n - 1; row >= 0; row--) {
    let value = a[row][n];
    for (let col = row + 1; col < n; col++) value -= a[row][col] * x[col];
    x[row] = value / a[row][row];
  }
  return x.every(Number.isFinite) ? x : null;
}

function components(branches) {
  const adjacency = NODES.map(() => []);
  for (const [a, b] of branches) { adjacency[a].push(b); adjacency[b].push(a); }
  const membership = new Array(4).fill(-1), groups = [];
  for (let i = 0; i < 4; i++) if (membership[i] < 0) {
    const group = [], queue = [i], id = groups.length;
    membership[i] = id;
    for (const node of queue) {
      group.push(node);
      for (const next of adjacency[node]) if (membership[next] < 0) { membership[next] = id; queue.push(next); }
    }
    groups.push(group);
  }
  return {membership, groups};
}

/** In disconnected active networks the unconnected component potentials are
 * gauges, not physical voltages. Off-diode inequalities bound their relative
 * offsets. Difference constraints choose a feasible offset without adding any
 * resistor, grounding current, dissipation or stored mechanical energy. */
function chooseGauge(base, topology, p, mask, tolerance) {
  const {membership, groups} = topology, edges = [];
  for (let i = 0; i < 4; i++) if (!(mask & (1 << i))) {
    const diode = p.diodes[i], [a, b] = diode.ports.map(n => NODE.get(n));
    const bound = diode.drop - (base[a] - base[b]);
    const from = membership[b], to = membership[a];
    if (from === to) { if (bound < -tolerance) return null; }
    else edges.push({from, to, bound});
  }
  const shift = new Array(groups.length).fill(0);
  for (let pass = 0; pass < groups.length; pass++) {
    let changed = false;
    for (const edge of edges) if (shift[edge.to] > shift[edge.from] + edge.bound + tolerance) {
      shift[edge.to] = shift[edge.from] + edge.bound; changed = true;
    }
    if (!changed) break;
    if (pass === groups.length - 1) return null;
  }
  const result = base.map((v, i) => v + shift[membership[i]]);
  const ground = result[NODE.get('N')];
  return result.map(v => v - ground);
}

const zeros = () => ({generatorWork: 0, motorWork: 0, storedDelta: 0,
  generatorHeat: 0, motorHeat: 0, diodeHeat: 0, capacitorBackwardEulerDefect: 0, residual: 0});

/** One backward-Euler electrical step at DECLARED CONSTANT port velocities.
 * A native contact-coupled mechanical solve is a separate future adapter.
 * No pre-step velocity predictor is presented as an end-velocity proof. */
export function solveRoom44SignedBridge({parameters: supplied = {}, voltage = 0, dt,
  generatorVelocity = 0, motorVelocity = 0} = {}) {
  const p = parameters(supplied), h = positive(dt, 'time step');
  finite(voltage, 'previous capacitor voltage');
  finite(.5 * p.capacitance * voltage ** 2, 'previous capacitor energy');
  finite(generatorVelocity, 'generator port velocity'); finite(motorVelocity, 'motor port velocity');
  const emf = p.generatorConstant * generatorVelocity, motorEmf = p.motorConstant * motorVelocity;
  finite(emf, 'generator EMF'); finite(motorEmf, 'motor back EMF');
  const capG = p.capacitance / h;
  positive(capG, 'finite capacitor conductance');
  const tolerance = 2e-10 * Math.max(1, Math.abs(emf), Math.abs(motorEmf), Math.abs(voltage));
  const pair = names => names.map(n => NODE.get(n)), sourcePair = pair(['A', 'B']), capPair = pair(['P', 'N']), motorPair = pair(p.motorPorts);
  const solutions = [];
  for (let mask = 0; mask < 16; mask++) {
    const matrix = Array.from({length: 4}, () => new Array(4).fill(0)), right = new Array(4).fill(0), branches = [];
    const add = ([a, b], conductance, seriesEmf) => {
      matrix[a][a] += conductance; matrix[a][b] -= conductance;
      matrix[b][b] += conductance; matrix[b][a] -= conductance;
      right[a] += conductance * seriesEmf; right[b] -= conductance * seriesEmf;
      branches.push([a, b]);
    };
    add(sourcePair, 1 / p.generatorResistance, emf);
    add(capPair, capG, voltage);
    add(motorPair, 1 / p.motorResistance, motorEmf);
    for (let i = 0; i < 4; i++) if (mask & (1 << i)) add(pair(p.diodes[i].ports), 1 / p.diodes[i].resistance, p.diodes[i].drop);
    const topology = components(branches);
    for (const group of topology.groups) { const anchor = group[0]; matrix[anchor].fill(0); matrix[anchor][anchor] = 1; right[anchor] = 0; }
    const base = solveLinear(matrix, right);
    if (!base) continue;
    const v = chooseGauge(base, topology, p, mask, tolerance);
    if (!v) continue;
    const drop = ([a, b]) => v[a] - v[b], currents = [], kcl = new Array(4).fill(0);
    let valid = true, constitutiveResidual = 0;
    const accumulate = ([a, b], current) => { kcl[a] += current; kcl[b] -= current; };
    for (let i = 0; i < 4; i++) {
      const diode = p.diodes[i], ij = pair(diode.ports), excess = drop(ij) - diode.drop, on = Boolean(mask & (1 << i));
      if ((on && excess < -tolerance) || (!on && excess > tolerance)) { valid = false; break; }
      const raw = on ? excess / diode.resistance : 0;
      // Only the roundoff-sized negative current allowed by the feasibility
      // tolerance becomes zero; a reverse-conducting active set is rejected.
      const current = Math.max(0, raw);
      constitutiveResidual = Math.max(constitutiveResidual, Math.abs(current - Math.max(0, excess / diode.resistance)));
      currents.push(current); accumulate(ij, current);
    }
    if (!valid) continue;
    const generatorCurrent = (emf - drop(sourcePair)) / p.generatorResistance;
    const motorCurrent = (drop(motorPair) - motorEmf) / p.motorResistance;
    const nextVoltage = drop(capPair), capacitorCurrent = capG * (nextVoltage - voltage);
    accumulate(sourcePair, -generatorCurrent); accumulate(capPair, capacitorCurrent); accumulate(motorPair, motorCurrent);
    const kclResidual = Math.max(...kcl.map(Math.abs));
    const currentScale = Math.max(1, Math.abs(generatorCurrent), Math.abs(motorCurrent), Math.abs(capacitorCurrent), ...currents);
    if (kclResidual > 2e-8 * currentScale || constitutiveResidual > 2e-8 * currentScale) continue;
    const ledger = {
      generatorWork: emf * generatorCurrent * h,
      motorWork: motorEmf * motorCurrent * h,
      storedDelta: .5 * p.capacitance * (nextVoltage ** 2 - voltage ** 2),
      generatorHeat: p.generatorResistance * generatorCurrent ** 2 * h,
      motorHeat: p.motorResistance * motorCurrent ** 2 * h,
      diodeHeat: p.diodes.reduce((sum, diode, i) => sum + (diode.drop * currents[i] + diode.resistance * currents[i] ** 2) * h, 0),
      capacitorBackwardEulerDefect: .5 * p.capacitance * (nextVoltage - voltage) ** 2,
    };
    ledger.residual = ledger.generatorWork - ledger.motorWork - ledger.storedDelta - ledger.generatorHeat - ledger.motorHeat - ledger.diodeHeat - ledger.capacitorBackwardEulerDefect;
    if (!Object.values(ledger).every(Number.isFinite)) continue;
    solutions.push({mask, nodeVoltages: Object.fromEntries(NODES.map((n, i) => [n, v[i]])), voltage: nextVoltage,
      emf, generatorCurrent, motorEmf, motorCurrent, capacitorCurrent, diodeCurrents: currents,
      generatorForce: -p.generatorConstant * generatorCurrent, motorForce: p.motorConstant * motorCurrent,
      kcl: Object.fromEntries(NODES.map((n, i) => [n, kcl[i]])), kclResidual, constitutiveResidual,
      gauges: {components: topology.groups.map(group => group.map(i => NODES[i])), dissipatedWork: 0, injectedCurrent: 0}, ledger});
  }
  if (!solutions.length) throw new Error('No finite complementary four-diode active set');
  // At exact zero-current boundaries multiple masks describe the same state.
  // Choose the first numerical solution deterministically; no wiring flag or
  // sign-based branch substitutes for the sixteen actual graph solves.
  const result = solutions[0];
  result.feasibleActiveSets = solutions.map(s => s.mask);
  result.parameters = p;
  result.dt = h;
  result.generatorVelocity = generatorVelocity; result.motorVelocity = motorVelocity;
  result.previousVoltage = voltage;
  result.scope = 'Electrical BE with externally declared constant port velocities; no native mechanical/contact acceptance';
  return result;
}

export class Room44SignedBridgeCircuit {
  constructor(options = {}) {
    this.parameters = parameters(options);
    this.voltage = finite(options.initialVoltage ?? 0, 'initial capacitor voltage');
    finite(.5 * this.parameters.capacitance * this.voltage ** 2, 'initial capacitor energy');
    this.steps = 0; this.time = 0; this.ledger = zeros();
  }
  step(dt, {generatorVelocity = 0, motorVelocity = 0} = {}) {
    const result = solveRoom44SignedBridge({parameters: this.parameters, voltage: this.voltage, dt, generatorVelocity, motorVelocity});
    // Validation and the full active-set solve precede the only state commit.
    const nextTime = finite(this.time + dt, 'accumulated time'), nextSteps = this.steps + 1;
    if (!Number.isSafeInteger(nextSteps)) throw new RangeError('Finite exact step count required');
    const nextLedger = Object.fromEntries(Object.keys(this.ledger).map(key => [key, finite(this.ledger[key] + result.ledger[key], 'accumulated ' + key)]));
    this.voltage = result.voltage; this.steps = nextSteps; this.time = nextTime; this.ledger = nextLedger;
    return result;
  }
  snapshot() {
    return {voltage: this.voltage, storedEnergy: .5 * this.parameters.capacitance * this.voltage ** 2,
      steps: this.steps, time: this.time, ledger: {...this.ledger}};
  }
}
