# Room 44 signed bridge: new source reconstruction

This is a new source-only electrical prototype. The lost prior files and their
test receipts are not available. No game integration, native test, browser,
route, GLB, contact or graphical acceptance is asserted.

The proposed core changes the repeated reverse-airflow task into a generator,
rectifier and polarized actuator. Cargo motion would be a signed physical
input; reversing motion changes generator EMF and the conducting diode pair.
The player would have to understand actual terminal polarity, retain energy in
storage, then deliver it to a motor. The real room, portal roles, finite physical
actuator and a usable ordinary journey remain design and implementation work.

The circuit has four explicit nodes: source A/B and output P/N. The correct
diodes are A→P, B→P, N→A and N→B. Every diode obeys

\[
i_d=\max\left(0,\frac{V_a-V_c-V_f}{R_d}\right).
\]

All sixteen diode active sets are assembled as actual nodal networks. The
algorithm solves their KCL equations and checks both conducting and blocking
inequalities. It does not use absolute EMF, a `wiringValid` gate or a graph
selection multiplier. The swapped AC/DC graph is another list of real diode
branches. Reversed motor leads change its actual terminal order.

The generator and motor laws at externally declared constant port velocities
are

\[
e=k_g v,\quad V_A-V_B=e-R_g I_g,\quad F_g=-k_g I_g,
\]
\[
V_{m+}-V_{m-}=k_m u+R_m I_m,\quad F_m=k_m I_m.
\]

The generator current is signed: positive current leaves its A terminal and
returns through B. The motor current is signed in its actual terminal order.
Thus reversed leads at zero motor velocity produce a real negative force.
Capacitor voltage is always measured P−N and backward Euler gives

\[
I_c=\frac{C}{h}(V_{n+1}-V_n).
\]

The nodal graph can become disconnected when all bridge diodes block. A
single ideal potential anchor per connected conductance component removes
only its mathematical common mode. Off-diode inequalities constrain the
relative component offsets. A small difference-constraints solve finds a
feasible offset without injecting current or adding a leak resistor. Full KCL
is checked again, including the rows temporarily replaced by gauge anchors.

Multiplying KCL by node potentials gives the per-step identity

\[
eI_g h-k_m u I_mh
=\Delta\left(\tfrac12 CV^2\right)
+R_gI_g^2h+R_mI_m^2h
+\sum_d\left(V_f i_d+R_d i_d^2\right)h
+\tfrac12 C(V_{n+1}-V_n)^2.
\]

The resistor and diode terms are nonnegative physical dissipation. The final
term is the nonnegative backward-Euler storage defect; it is recorded
separately and is not called heat. Generator and motor work remain signed,
including mechanical backdrive. Invalid inputs and failed active-set solves
must precede every state commit.

The tentative numerical component values are new explicit design parameters,
not a recovered accepted calibration: `kg=4`, `Rg=.7`, `C=1.5`, `km=6`,
`Rm=3`, `Vf=.25`, `Rd=.08`. No native mass is being substituted for electrical
capacitance. This file makes no claim that these values lift a room door or
produce an enjoyable puzzle.

The ten prepared tests cover signed conducting paths, a physically miswired
graph, reversed motor terminals, capacitor drive, mechanical backdrive,
unequal actual diodes, a 240-step signed waveform, 512 deterministic parameter
cases, atomic invalid input and zero-power floating gauges. They have not been
executed. A test file is not evidence of a pass.

Before any mechanical integration, an adapter must couple to actual original
3.2 kg / 0.78 m cargo and the actual actuator. Contact/constraint impulses can
change end velocity. Cannon's constraint impulse, damping and force order
must be derived explicitly; this constant-port circuit cannot validate a
pre-step-velocity predictor or a contact-coupled energy identity. Spatial flux,
portal transport, carrying, real work transfer, recovery, full routes and
usability also remain open.
