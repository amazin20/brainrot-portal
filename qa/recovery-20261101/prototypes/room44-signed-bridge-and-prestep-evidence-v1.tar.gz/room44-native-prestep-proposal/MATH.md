# New room 44 post-solver force adapter: source proposal

This proposal is outside the game source. No native execution result is
asserted. It implements a bounded component stage, not the actual new room.

The local primary package is cannon-es 0.20.0. Its actual CJS implementation
calls `solver.solve(dt, world)` at line 12806, applies native damping, dispatches
`preStep` at 12834, integrates the bodies at 12847, clears forces, increments
the step number and dispatches `postStep`. Body integration uses
`v += force * (invMass * dt)` followed by `position += v * dt`.

`postStep` precedes `sleepTick`; the outer `World.step` updates `world.time`
after internal stepping returns. Therefore this bounded stage requires a
fixture explicitly declared with `World.allowSleep=false`. The adapter does
not change that flag, cargo `allowSleep`, mass, damping, material, shape,
velocity, pose or clocks. A production world with automatic sleep needs a
separate final-boundary observation, for example a read-only `finalizeStep()`
after the actual `World.step` returns. That extension is not implemented or
accepted here. Native sleep zeroing must be recorded as a separate numerical
kinetic loss, not physical heat.

The adapter observes the actual original 3.2 kg / 0.78 m cargo and a distinct
provided motor body. Original cargo damping .035/.16, original material
friction/restitution 1/1, shape/local transform and all retained object
identities are checked. Neither body is reconstructed or reconfigured.
Both must be awake native dynamic single-Box bodies with `linearFactor111`.
Generator and motor force axes are fixed unit world vectors; applied forces
are centre forces with no electrical torque or spatially varying flux.

Let the solver produce velocity \(v_s\), then native damping produce \(v_d\).
The adapter is the last frozen `preStep` listener, so it observes every earlier
pending force contribution \(F_0\), including native gravity. Define

\[
v_{free}=v_d+hF_0/m.
\]

For the generator and motor port projections \(q_{free},u_{free}\), solve the
same explicit four-diode circuit with

\[
e_{free}=k_g q_{free},\qquad
R_{g,eff}=R_g+h k_g^2/m_g,
\]
\[
e_{m,free}=k_m u_{free},\qquad
R_{m,eff}=R_m+h k_m^2/m_m.
\]

Then queue only \(F_g=-k_gI_g a_g\) and \(F_m=k_mI_m a_m\) in the actual
native force vectors, preserving all pre-existing forces and torques. Normal
native integration gives

\[
q_1=q_{free}-h k_g I_g/m_g,\qquad
u_1=u_{free}+h k_m I_m/m_m.
\]

Consequently the actual end velocities satisfy the original physical laws
\(V_{AB}=k_gq_1-R_gI_g\) and
\(V_{m+}-V_{m-}=k_mu_1+R_mI_m\). The effective-resistance additions are an
algebraic elimination of end velocity, not copper resistors or heat.

The first frozen `postStep` observer measures the actual displacement and
velocity. Electrical mechanical work is

\[
W_g=-F_g\cdot\Delta x_g,\qquad W_m=F_m\cdot\Delta x_m.
\]

Changing from the effective circuit ports to these actual mechanical ports
removes exactly \(h^2k_g^2I_g^2/m_g\) and
\(h^2k_m^2I_m^2/m_m\) from the effective resistive ledger. Physical heat uses
only the original \(R_g,R_m\) and actual diode losses. The capacitor's BE
defect is retained separately:

\[
W_g-W_m=\Delta E_c+H_{physical}+B_{cap},\qquad
B_{cap}=\tfrac12 C(\Delta V)^2.
\]

For every owned body, the read-only native solver wrapper captures
translational kinetic energy immediately before and after `solver.solve`.
That stated starting boundary excludes earlier collision-event impulses from
other owners. The signed difference \(S=K_s-K_0\) is measured, never inferred
by dividing damping. It can contain contact and constraint stabilization
energy, friction loss and native external-force terms. A positive value is
not converted to heat or silently dropped.

Native damping loss is \(D=K_s-K_d\). With total pending-plus-electrical force,
the integration identity is

\[
K_1-K_d=F_0\cdot\Delta x+F_e\cdot\Delta x-B_F,
\qquad B_F=\tfrac12m\lVert v_1-v_d\rVert^2.
\]

`BF` uses the total force kick, not just the electrical force. Combining both
owned bodies with the capacitor gives the translational/electrical closure

\[
\Delta K+\Delta E_c
=S-D+W_0-H_{physical}-B_{cap}-B_F.
\]

Each actual measured residual is reported. The equation includes the signed
native solver term; it does not establish that Cannon contact bias is passive.
Actual quaternion, angular velocity, original inertia, torque and rotational
energy at all stages are observed and preserved. General anisotropic
rotational work is outside this translational closure, and no global
rigid-body conservation claim is made.

The listener arrays and complete pre/post listener memberships are frozen.
This matters because EventTarget captures array length before dispatch: an
earlier callback appending listeners must be rejected before the force queue.
A preStep impulse or pose change by another owner fails the expected native
damping boundary. Every physical value for both bodies is checked before
either force is written. Capacitor state commits only after actual native
integration and work laws agree. Dispose restores every owned listener and
the original solver descriptor; it never rewinds a partial failed World step.

Contacts and constraints were already solved before these electrical force
kicks. The kicks may reopen a velocity/contact residual until the next step.
This is explicitly tested as a limitation; the adapter is not a fully coupled
electromechanical constraint solve. Real generator geometry, spatial flux,
held cargo, portals, actual actuator/gear work, the production sleep boundary,
ordinary journeys, recovery, usability and graphical room acceptance remain
open. The new core is a candidate replacement for repeated reverse airflow,
not an accepted completed room.
