/** NEW SOURCE-ONLY Node component adapter. It starts no World, step, browser,
 * game or build. Caller supplies the actual unchanged bodies and World.
 * Mechanical scope: constant world-space centre-force axes, native normal
 * integration, electrical work plus TRANSLATIONAL kinetic energy only.
 */
import {createRequire} from 'node:module';
import {Room44SignedBridgeCircuit, solveRoom44SignedBridge} from '../room44-signed-bridge-proposal/Room44SignedBridgeCircuit.mjs';
const require = createRequire(new URL('../../brainrot-portal/package.json', import.meta.url));
const {Body, Box, Vec3, World, GSSolver} = require('cannon-es');
const NATIVE_SOLVE = GSSolver.prototype.solve;
const NATIVE_VECTOR_SET = Vec3.prototype.set;

const vector = value => [value.x, value.y, value.z];
const quaternion = value => [...vector(value), value.w];
const dot = (a, b) => a.reduce((sum, value, i) => sum + value * b[i], 0);
const subtract = (a, b) => a.map((v, i) => v - b[i]);
const scale = (a, s) => a.map(v => v * s);
const finite = (value, label) => { if (!Number.isFinite(value)) throw new TypeError('Finite ' + label + ' required'); return value; };
const finiteVector = (value, label) => { if (!Array.isArray(value) || value.length !== 3 || !value.every(Number.isFinite)) throw new TypeError('Finite vector ' + label + ' required'); return value; };
const equal = (a, b) => a.length === b.length && a.every((v, i) => Object.is(v, b[i]));
const near = (a, b, label, tolerance = 2e-10) => {
  if (a.length !== b.length || a.some((v, i) => Math.abs(v - b[i]) > tolerance * Math.max(1, Math.abs(v), Math.abs(b[i])))) throw new Error(label + ' differs from native integration');
};
function axis(value, label) {
  const a = Array.isArray(value) ? [...value] : vector(value ?? {});
  finiteVector(a, label);
  if (Math.abs(dot(a, a) - 1) > 1e-12) throw new RangeError('Declared unit world-space ' + label + ' required');
  return Object.freeze(a);
}
function writableForce(body) {
  const force = body.force;
  if (Object.getPrototypeOf(force) !== Vec3.prototype || ['x', 'y', 'z'].some(key => {
    const d = Object.getOwnPropertyDescriptor(force, key); return !d || !Object.hasOwn(d, 'value') || d.writable !== true;
  })) throw new TypeError('Plain writable native force components required before any queue');
}
function pinBody(body, world, cargo = false) {
  if (!(body instanceof Body) || body.world !== world || !world.bodies.includes(body) || body.type !== Body.DYNAMIC || !(body.mass > 0)
    || !Number.isFinite(body.mass) || body.shapes.length !== 1 || !(body.shapes[0] instanceof Box) || body.sleepState === Body.SLEEPING)
    throw new TypeError('Present awake native dynamic single-Box body required');
  const shape = body.shapes[0];
  if (shape.body !== body || !equal(vector(body.linearFactor), [1, 1, 1]) || body.integrate !== Body.prototype.integrate)
    throw new TypeError('Unmodified native integrate and linearFactor111 required');
  if (!(body.linearDamping >= 0 && body.linearDamping < 1 && body.angularDamping >= 0 && body.angularDamping < 1))
    throw new RangeError('Finite ordinary native damping required');
  if (cargo && (body.mass !== 3.2 || !equal(vector(shape.halfExtents), [.39, .39, .39]) || body.linearDamping !== .035 || body.angularDamping !== .16
    || !body.material || body.material.friction !== 1 || body.material.restitution !== 1
    || !equal(vector(body.shapeOffsets[0]), [0, 0, 0]) || !equal(quaternion(body.shapeOrientations[0]), [0, 0, 0, 1])))
    throw new TypeError('The original 3.2kg/.78m cargo material, damping and local shape transform are required');
  const references = Object.fromEntries(['position', 'quaternion', 'velocity', 'angularVelocity', 'force', 'torque', 'linearFactor', 'angularFactor', 'inertia', 'invInertia', 'invInertiaWorld'].map(k => [k, body[k]]));
  const result = {body, world, shape, shapes: body.shapes, shapeOffsets: body.shapeOffsets, shapeOrientations: body.shapeOrientations,
    offset: body.shapeOffsets[0], orientation: body.shapeOrientations[0], material: body.material, shapeMaterial: shape.material,
    halfObject: shape.halfExtents, half: vector(shape.halfExtents), localOffset: vector(body.shapeOffsets[0]), localOrientation: quaternion(body.shapeOrientations[0]),
    mass: body.mass, invMass: body.invMass, linearDamping: body.linearDamping, angularDamping: body.angularDamping,
    allowSleep: body.allowSleep, sleepSpeedLimit: body.sleepSpeedLimit, sleepTimeLimit: body.sleepTimeLimit,
    materialState: body.material ? [body.material.friction, body.material.restitution] : null,
    angularFactor: vector(body.angularFactor), inertia: vector(body.inertia), invInertia: vector(body.invInertia), references};
  for (const v of [result.half, result.localOffset, result.localOrientation, result.angularFactor, result.inertia, result.invInertia])
    if (!v.every(Number.isFinite)) throw new TypeError('Finite native body parameters required');
  if (result.half.some(v => v <= 0) || body.invMass !== 1 / body.mass) throw new RangeError('Unchanged native mass/inverse mass and Box dimensions required');
  writableForce(body);
  return result;
}
function assertBody(pin) {
  const b = pin.body;
  if (b.world !== pin.world || !pin.world.bodies.includes(b) || b.type !== Body.DYNAMIC || b.sleepState === Body.SLEEPING
    || b.mass !== pin.mass || b.invMass !== pin.invMass || b.shapes !== pin.shapes || b.shapes.length !== 1 || b.shapes[0] !== pin.shape
    || b.shapeOffsets !== pin.shapeOffsets || b.shapeOrientations !== pin.shapeOrientations || b.shapeOffsets[0] !== pin.offset || b.shapeOrientations[0] !== pin.orientation
    || pin.shape.body !== b || b.material !== pin.material || pin.shape.material !== pin.shapeMaterial
    || b.linearDamping !== pin.linearDamping || b.angularDamping !== pin.angularDamping || b.integrate !== Body.prototype.integrate
    || b.allowSleep !== pin.allowSleep || b.sleepSpeedLimit !== pin.sleepSpeedLimit || b.sleepTimeLimit !== pin.sleepTimeLimit
    || pin.shape.halfExtents !== pin.halfObject || !equal(vector(pin.shape.halfExtents), pin.half) || !equal(vector(pin.offset), pin.localOffset) || !equal(quaternion(pin.orientation), pin.localOrientation)
    || !equal(vector(b.linearFactor), [1, 1, 1]) || !equal(vector(b.angularFactor), pin.angularFactor)
    || !equal(vector(b.inertia), pin.inertia) || !equal(vector(b.invInertia), pin.invInertia)
    || pin.material && !equal([pin.material.friction, pin.material.restitution], pin.materialState)
    || Object.entries(pin.references).some(([key, ref]) => b[key] !== ref)) throw new Error('Original native body/shape/material/mass/damping owner changed');
}
function observed(pin) {
  const b = pin.body, p = finiteVector(vector(b.position), 'body position'), v = finiteVector(vector(b.velocity), 'body velocity'), w = finiteVector(vector(b.angularVelocity), 'angular velocity');
  const q = quaternion(b.quaternion), force = finiteVector(vector(b.force), 'pending force'), torque = finiteVector(vector(b.torque), 'pending torque');
  if (!q.every(Number.isFinite) || Math.abs(dot(q, q) - 1) > 1e-8) throw new TypeError('Finite unit native body quaternion required');
  const localAngular = b.quaternion.conjugate().vmult(b.angularVelocity);
  const rotationalEnergyObserved = finite(.5 * dot(pin.inertia, vector(localAngular).map(n => n * n)), 'observed rotational energy');
  return {bodyId: b.id, shapeId: pin.shape.id, mass: b.mass, half: [...pin.half], p, q, v, w, force, torque,
    translationalKinetic: finite(.5 * b.mass * dot(v, v), 'observed translational energy'), rotationalEnergyObserved};
}

export class NativePreStepBridgeAdapter {
  #world; #solver; #pins; #axes; #parameters; #voltage; #steps = 0; #time = 0;
  #phase = 'idle'; #failure = null; #disposed = false; #stage = null; #pending = null; #latest = null;
  #solverSlot; #solverWrapper; #pre; #post; #listenerRecords = []; #listenersDescriptor; #listenersObject; #listenerInventory;
  #totals = {generatorWorkActual: 0, motorWorkActual: 0, capacitorDelta: 0, physicalHeat: 0, capacitorBEDefect: 0,
    forceBEDefect: 0, pendingForceWork: 0, solverKineticDeltaSigned: 0, nativeDampingLoss: 0, combinedResidual: 0};
  constructor({world, generatorBody, motorBody, generatorAxis = [0, 0, 1], motorAxis = [0, 1, 0], circuit = {}} = {}) {
    if (!(world instanceof World) || !(world.solver instanceof GSSolver) || generatorBody === motorBody)
      throw new TypeError('Actual native World/GSSolver and two distinct bodies required');
    if (world.solver.solve !== NATIVE_SOLVE || GSSolver.prototype.solve !== NATIVE_SOLVE)
      throw new TypeError('An unchanged native GSSolver.solve is required');
    // Native postStep precedes sleepTick. This bounded first stage therefore
    // requires a fixture declared without automatic World sleep. It changes
    // neither that flag nor the original cargo's own sleep configuration.
    if (world.allowSleep !== false) throw new Error('Declare World.allowSleep=false for this bounded pre-sleep prototype');
    if (world.step !== World.prototype.step || world.internalStep !== World.prototype.internalStep || world.dispatchEvent !== World.prototype.dispatchEvent
      || world.bodies.some(b => b.integrate !== Body.prototype.integrate)) throw new TypeError('Normal native World and Body integration order required');
    const post = world._listeners?.postStep;
    if (post && post.length) throw new Error('Attach the adapter before every other postStep observer or mutator');
    this.#world = world; this.#solver = world.solver;
    this.#pins = [pinBody(generatorBody, world, true), pinBody(motorBody, world, false)];
    this.#axes = [axis(generatorAxis, 'generator axis'), axis(motorAxis, 'motor axis')];
    const prepared = new Room44SignedBridgeCircuit(circuit);
    this.#parameters = prepared.parameters; this.#voltage = prepared.voltage;
    for (const pin of this.#pins) observed(pin);
    const descriptor = Object.getOwnPropertyDescriptor(this.#solver, 'solve'), original = this.#solver.solve;
    if (typeof original !== 'function' || descriptor && (!descriptor.writable || !descriptor.configurable) || !descriptor && !Object.isExtensible(this.#solver))
      throw new TypeError('An exactly restorable native solver observation slot is required');
    this.#solverSlot = {descriptor, original};
    this.#listenersDescriptor = Object.getOwnPropertyDescriptor(world, '_listeners');
    const owner = this;
    this.#solverWrapper = function(...args) { return owner.#observeSolve(this, args); };
    this.#pre = () => this.#guard(() => this.#beforeIntegration());
    this.#post = () => this.#guard(() => this.#afterIntegration());
    try {
      Object.defineProperty(this.#solver, 'solve', {value: this.#solverWrapper, writable: true, configurable: true, enumerable: descriptor?.enumerable ?? false});
      for (const [key, fn] of [['preStep', this.#pre], ['postStep', this.#post]]) {
        const existed = Boolean(world._listeners?.[key]);
        world.addEventListener(key, fn);
        this.#listenerRecords.push({key, fn, array: world._listeners[key], existed});
        this.#listenersObject = world._listeners;
      }
      this.#listenerInventory = this.#listenerRecords.map(r => ({key: r.key, array: r.array, functions: [...r.array]}));
      this.validateBoundary();
    } catch (error) { const errors = this.#restore(); throw new Error(String(error.stack ?? error) + (errors.length ? '; cleanup: ' + errors.join('; ') : '')); }
  }
  #guard(action) {
    try { return action(); }
    catch (error) { this.#failure = String(error.stack ?? error); this.#phase = 'failed'; throw error; }
  }
  #ownersAndOrder() {
    const w = this.#world;
    if (this.#disposed || this.#failure || w.allowSleep !== false || w.solver !== this.#solver || this.#solver.solve !== this.#solverWrapper
      || w.step !== World.prototype.step || w.internalStep !== World.prototype.internalStep || w.dispatchEvent !== World.prototype.dispatchEvent
      || w.bodies.some(b => b.integrate !== Body.prototype.integrate)) throw new Error('Active unchanged native World/solver owners required');
    if (w._listeners?.preStep?.at(-1) !== this.#pre || w._listeners?.postStep?.[0] !== this.#post)
      throw new Error('Adapter must remain LAST preStep and FIRST postStep');
    for (const inventory of this.#listenerInventory) {
      const current = w._listeners?.[inventory.key];
      if (current !== inventory.array || current.length !== inventory.functions.length || current.some((fn, i) => fn !== inventory.functions[i]))
        throw new Error('Complete preStep/postStep listener inventories must remain frozen');
    }
    for (const pin of this.#pins) assertBody(pin);
    if (!Number.isSafeInteger(w.stepnumber) || w.stepnumber < 0 || !Number.isFinite(w.time)) throw new Error('Finite unchanged native World clocks required');
  }
  validateBoundary() {
    this.#ownersAndOrder();
    if (this.#phase !== 'idle' || this.#pending) throw new Error('Previous actual native step has not completed');
    return true;
  }
  #observeSolve(receiver, args) {
    return this.#guard(() => {
      this.validateBoundary();
      const [h, world] = args;
      if (receiver !== this.#solver || world !== this.#world || !(h > 0) || !Number.isFinite(h) || world.dt !== h) throw new Error('Actual matching native solver call required');
      this.#stage = {h, stepnumber: world.stepnumber, worldTime: world.time, beforeSolve: this.#pins.map(observed)};
      this.#phase = 'solving';
      const result = this.#solverSlot.original.apply(receiver, args);
      this.#stage.afterSolve = this.#pins.map(observed); this.#phase = 'after-solve';
      return result;
    });
  }
  #beforeIntegration() {
    this.#ownersAndOrder();
    if (this.#phase !== 'after-solve' || !this.#stage || this.#pending) throw new Error('Native solve must precede native preStep');
    const s = this.#stage, h = s.h, before = this.#pins.map(observed);
    const free = before.map((o, i) => {
      const solved = s.afterSolve[i], pin = this.#pins[i];
      near(o.p, solved.p, 'PreStep position'); near(o.q, solved.q, 'PreStep quaternion');
      near(o.v, scale(solved.v, Math.pow(1 - pin.linearDamping, h)), 'Actual native damping');
      near(o.w, scale(solved.w, Math.pow(1 - pin.angularDamping, h)), 'Actual native angular damping');
      return o.v.map((v, k) => finite(v + o.force[k] * (pin.body.invMass * h), 'pending-force free velocity'));
    });
    const p = this.#parameters, effective = {...p,
      generatorResistance: p.generatorResistance + h * p.generatorConstant ** 2 / this.#pins[0].mass,
      motorResistance: p.motorResistance + h * p.motorConstant ** 2 / this.#pins[1].mass};
    const electrical = solveRoom44SignedBridge({parameters: effective, voltage: this.#voltage, dt: h,
      generatorVelocity: dot(this.#axes[0], free[0]), motorVelocity: dot(this.#axes[1], free[1])});
    const ownForces = [scale(this.#axes[0], -p.generatorConstant * electrical.generatorCurrent), scale(this.#axes[1], p.motorConstant * electrical.motorCurrent)];
    const totals = before.map((o, i) => o.force.map((f, k) => finite(f + ownForces[i][k], 'total queued force')));
    const predicted = before.map((o, i) => o.v.map((v, k) => finite(v + totals[i][k] * (this.#pins[i].body.invMass * h), 'native end velocity')));
    for (let i = 0; i < 2; i++) {
      finite(.5 * this.#pins[i].mass * dot(predicted[i], predicted[i]), 'predicted native translational energy');
      finiteVector(before[i].p.map((x, k) => x + predicted[i][k] * h), 'predicted native position');
    }
    // Every value and both bodies are validated before either force is queued.
    this.#ownersAndOrder();
    for (let i = 0; i < 2; i++) {
      writableForce(this.#pins[i].body);
      if (!equal(vector(this.#pins[i].body.force), before[i].force) || !equal(vector(this.#pins[i].body.torque), before[i].torque)) throw new Error('Pending force/torque changed during synchronous circuit solve');
    }
    this.#pending = {before, free, electrical, ownForces, totals, predicted};
    for (let i = 0; i < 2; i++) NATIVE_VECTOR_SET.call(this.#pins[i].body.force, ...totals[i]);
    this.#phase = 'force-queued';
  }
  #afterIntegration() {
    this.#ownersAndOrder();
    if (this.#phase !== 'force-queued' || !this.#pending) throw new Error('Native force queue must precede actual postStep');
    const s = this.#stage, p = this.#pending, h = s.h, real = this.#parameters;
    if (this.#world.stepnumber !== s.stepnumber + 1 || this.#world.dt !== h || this.#world.time !== s.worldTime) throw new Error('Actual unchanged native step clock sequence required');
    const after = this.#pins.map(observed), rows = after.map((end, i) => {
      const begin = p.before[i], solved = s.afterSolve[i], initial = s.beforeSolve[i], mass = this.#pins[i].mass;
      near(end.v, p.predicted[i], 'Native force-integrated velocity'); near(end.p, begin.p.map((x, k) => x + end.v[k] * h), 'Native integrated displacement');
      near(end.force, [0, 0, 0], 'Native force clearing'); near(end.torque, [0, 0, 0], 'Native torque clearing');
      const displacement = subtract(end.p, begin.p), kick = subtract(end.v, begin.v);
      const row = {beforeSolve: initial, afterSolve: solved, damped: begin, forceIntegrated: end, displacement,
        pendingForce: begin.force, electricalForce: p.ownForces[i], totalQueuedForce: p.totals[i],
        pendingForceWork: dot(begin.force, displacement), electricalBodyWork: dot(p.ownForces[i], displacement),
        solverKineticDeltaSigned: solved.translationalKinetic - initial.translationalKinetic,
        nativeDampingLoss: solved.translationalKinetic - begin.translationalKinetic,
        forceBEDefect: .5 * mass * dot(kick, kick),
        translationalDelta: end.translationalKinetic - initial.translationalKinetic,
        rotationObservedNotBudgeted: {solverDelta: solved.rotationalEnergyObserved - initial.rotationalEnergyObserved,
          dampingDelta: begin.rotationalEnergyObserved - solved.rotationalEnergyObserved,
          integrationDelta: end.rotationalEnergyObserved - begin.rotationalEnergyObserved}};
      row.forceWorkResidual = end.translationalKinetic - begin.translationalKinetic - row.pendingForceWork - row.electricalBodyWork + row.forceBEDefect;
      return row;
    });
    const electrical = p.electrical, ig = electrical.generatorCurrent, im = electrical.motorCurrent;
    const generatorWorkActual = -rows[0].electricalBodyWork, motorWorkActual = rows[1].electricalBodyWork;
    const generatorHeat = real.generatorResistance * ig ** 2 * h, motorHeat = real.motorResistance * im ** 2 * h;
    const physicalHeat = generatorHeat + motorHeat + electrical.ledger.diodeHeat;
    const capacitorDelta = electrical.ledger.storedDelta, capacitorBEDefect = electrical.ledger.capacitorBackwardEulerDefect;
    const sum = key => rows.reduce((v, row) => v + row[key], 0);
    const ledger = {generatorWorkActual, motorWorkActual, capacitorDelta, generatorHeat, motorHeat, diodeHeat: electrical.ledger.diodeHeat, physicalHeat, capacitorBEDefect,
      forceBEDefect: sum('forceBEDefect'), pendingForceWork: sum('pendingForceWork'), solverKineticDeltaSigned: sum('solverKineticDeltaSigned'), nativeDampingLoss: sum('nativeDampingLoss'),
      electricalResidual: generatorWorkActual - motorWorkActual - capacitorDelta - physicalHeat - capacitorBEDefect,
      combinedResidual: sum('translationalDelta') + capacitorDelta - sum('solverKineticDeltaSigned') + sum('nativeDampingLoss') - sum('pendingForceWork') + physicalHeat + capacitorBEDefect + sum('forceBEDefect'),
      effectiveResistanceTermsNotHeat: {generator: h ** 2 * real.generatorConstant ** 2 * ig ** 2 / this.#pins[0].mass,
        motor: h ** 2 * real.motorConstant ** 2 * im ** 2 / this.#pins[1].mass}};
    const node = electrical.nodeVoltages, motorPorts = real.motorPorts;
    const physicalVoltageResidual = {
      generator: node.A - node.B - (real.generatorConstant * dot(this.#axes[0], after[0].v) - real.generatorResistance * ig),
      motor: node[motorPorts[0]] - node[motorPorts[1]] - (real.motorConstant * dot(this.#axes[1], after[1].v) + real.motorResistance * im)};
    const workScale = Math.max(1, ...Object.values(ledger).filter(v => typeof v === 'number').map(Math.abs));
    for (const residual of [ledger.electricalResidual, ledger.combinedResidual, ...rows.map(r => r.forceWorkResidual)])
      if (!Number.isFinite(residual) || Math.abs(residual) > 5e-9 * workScale) throw new Error('Actual native end-state/work identity failed');
    const voltageScale = Math.max(1, ...Object.values(node).map(Math.abs), Math.abs(real.generatorConstant * dot(this.#axes[0], after[0].v)), Math.abs(real.motorConstant * dot(this.#axes[1], after[1].v)));
    for (const residual of Object.values(physicalVoltageResidual))
      if (!Number.isFinite(residual) || Math.abs(residual) > 5e-9 * voltageScale) throw new Error('Actual native end-velocity voltage law failed');
    const nextTime = finite(this.#time + h, 'electrical elapsed time'), nextTotals = {};
    for (const key of Object.keys(this.#totals)) nextTotals[key] = finite(this.#totals[key] + ledger[key], 'accumulated ' + key);
    this.#latest = {h, nativeStep: this.#world.stepnumber, nativeWorldTimeAtSolve: s.worldTime, nativeWorldTimeAtPost: this.#world.time, rows, ledger, physicalVoltageResidual,
      electrical: {voltage: electrical.voltage, previousVoltage: electrical.previousVoltage, generatorCurrent: ig, motorCurrent: im,
        diodeCurrents: electrical.diodeCurrents, nodeVoltages: node, mask: electrical.mask, kclResidual: electrical.kclResidual},
      nativeContacts: this.#world.contacts.length, nativeConstraints: this.#world.constraints.length,
      fullyCoupledConstraintsAccepted: false, globalRigidBodyConservationAccepted: false,
      scope: 'Post-solver force integration with constant centre-force axes. Signed solver work may include contact stabilization injection. Rotation is observed but excluded from translational/electrical closure.'};
    // The electrical state commits only after the real native postStep agrees.
    this.#voltage = electrical.voltage; this.#steps++; this.#time = nextTime; this.#totals = nextTotals;
    this.#pending = null; this.#stage = null; this.#phase = 'idle';
  }
  snapshot() {
    return structuredClone({voltage: this.#voltage, storedEnergy: .5 * this.#parameters.capacitance * this.#voltage ** 2,
      steps: this.#steps, time: this.#time, phase: this.#phase, failure: this.#failure, disposed: this.#disposed,
      totals: this.#totals, latest: this.#latest, pending: Boolean(this.#pending),
      noPoseOrVelocityAssignments: true, fullyCoupledConstraintsAccepted: false, globalRigidBodyConservationAccepted: false});
  }
  #restore() {
    const errors = [], world = this.#world;
    for (const record of this.#listenerRecords.splice(0).reverse()) try {
      const current = world._listeners?.[record.key];
      for (const array of new Set([record.array, current].filter(Array.isArray))) {
        let index; while ((index = array.indexOf(record.fn)) >= 0) array.splice(index, 1);
      }
      if (!record.existed && current?.length === 0) delete world._listeners[record.key];
    } catch (error) { errors.push(String(error)); }
    try {
      if (this.#solver.solve !== this.#solverWrapper) throw new Error('Refusing to replace another solver owner during cleanup');
      if (this.#solverSlot.descriptor) Object.defineProperty(this.#solver, 'solve', this.#solverSlot.descriptor); else delete this.#solver.solve;
      if (this.#solver.solve !== this.#solverSlot.original) throw new Error('Original native solver method did not restore');
    } catch (error) { errors.push(String(error)); }
    try {
      if (world._listeners === this.#listenersObject && Object.keys(world._listeners).length === 0) {
        if (this.#listenersDescriptor) Object.defineProperty(world, '_listeners', this.#listenersDescriptor); else delete world._listeners;
      }
    } catch (error) { errors.push(String(error)); }
    return errors;
  }
  dispose() {
    if (this.#disposed) return;
    this.#disposed = true;
    const errors = this.#restore();
    if (errors.length) throw new Error('Every owned cleanup attempted: ' + errors.join('; '));
    // Native integration is never rolled back. Disposing a failed/incomplete
    // step restores hooks only; it cannot certify or rewind a partial World.
  }
}
