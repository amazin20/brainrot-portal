/** NEW SOURCE-ONLY tests. No run is claimed until a separate receipt exists.
 * Every positive call uses normal native World.step. Only constructor setup
 * and declared physical force/impulse fixtures choose initial motion.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {LabPhysics} from '../../brainrot-portal/src/game/LabPhysics.js';
import {NativePreStepBridgeAdapter} from './NativePreStepBridgeAdapter.mjs';
import {ROOM44_SWAPPED_AC_DC_DIODE_PORTS} from '../room44-signed-bridge-proposal/Room44SignedBridgeCircuit.mjs';
const require = createRequire(new URL('../../brainrot-portal/package.json', import.meta.url));
const {Body, Box, Material, Vec3, DistanceConstraint} = require('cannon-es');
const vector = v => [v.x, v.y, v.z], close = (a, b, tolerance = 2e-8) => assert.ok(Math.abs(a - b) <= tolerance, `${a} differs from ${b}`);
const declarations = [];

function fixture({velocity = 6, motorVelocity = 0, gravity = 0, contact = false,
  generatorAxis = [0, 0, 1], motorAxis = [0, 1, 0], circuit = {}, contributor = null, link = false} = {}) {
  const physics = new LabPhysics({gravity}), world = physics.world;
  // DECLARED component fixture, not a game/world configuration change made by
  // the adapter. Original cargo.allowSleep remains true and is identity-pinned.
  world.allowSleep = false;
  const generator = physics.createCargo({position: [0, contact ? .37 : 0, 0], velocity: generatorAxis.map(v => v * velocity)});
  const motor = new Body({mass: 5, shape: new Box(new Vec3(.3, .4, .3)), position: new Vec3(10, contact ? .4 : 0, 0),
    velocity: new Vec3(...motorAxis.map(v => v * motorVelocity)), linearDamping: .05, angularDamping: .08});
  world.addBody(motor);
  if (contact) world.addBody(new Body({mass: 0, shape: new Box(new Vec3(8, .5, 8)), position: new Vec3(0, -.5, 0), material: new Material({friction: .64, restitution: .08})}));
  if (link) world.addConstraint(new DistanceConstraint(generator, motor, 10, 1e6));
  const bodies = [generator, motor], shapes = bodies.map(b => b.shapes[0]), materials = bodies.map(b => b.material), nativeSolve = world.solver.solve;
  const pre = contributor ? () => contributor({world, generator, motor}) : null;
  if (pre) world.addEventListener('preStep', pre);
  const adapter = new NativePreStepBridgeAdapter({world, generatorBody: generator, motorBody: motor, generatorAxis, motorAxis, circuit});
  declarations.push({worldSleep: false, cargoSleep: generator.allowSleep, originalMass: generator.mass, originalHalf: vector(shapes[0].halfExtents), contact, link});
  const owners = () => {
    bodies.forEach((body, i) => { assert.equal(world.bodies.includes(body), true); assert.equal(body.shapes[0], shapes[i]); assert.equal(body.material, materials[i]); });
    assert.equal(generator.mass, 3.2); assert.deepEqual(vector(generator.shapes[0].halfExtents), [.39, .39, .39]);
    assert.equal(generator.linearDamping, .035); assert.equal(generator.angularDamping, .16); assert.equal(generator.allowSleep, true);
  };
  const step = h => { adapter.validateBoundary(); world.step(h); owners(); return adapter.snapshot(); };
  const dispose = () => {
    adapter.dispose(); adapter.dispose(); assert.equal(world.solver.solve, nativeSolve);
    if (pre) { assert.equal(world.hasEventListener('preStep', pre), true); world.removeEventListener('preStep', pre); }
    assert.equal(world._listeners?.preStep?.length ?? 0, 0); assert.equal(world._listeners?.postStep?.length ?? 0, 0);
    for (const c of [...world.constraints]) world.removeConstraint(c);
    physics.dispose(); assert.equal(world.bodies.length, 0);
  };
  return {physics, world, generator, motor, bodies, shapes, materials, adapter, nativeSolve, owners, step, dispose};
}

function check(snapshot, fixture, h) {
  assert.equal(snapshot.failure, null); assert.equal(snapshot.phase, 'idle');
  const r = snapshot.latest, e = r.ledger;
  assert.ok(r); assert.equal(r.h, h); assert.equal(r.nativeStep, fixture.world.stepnumber);
  close(fixture.world.time, snapshot.time, 1e-12); assert.equal(r.nativeWorldTimeAtSolve, r.nativeWorldTimeAtPost);
  assert.equal(snapshot.fullyCoupledConstraintsAccepted, false); assert.equal(snapshot.globalRigidBodyConservationAccepted, false);
  for (const key of ['electricalResidual', 'combinedResidual']) close(e[key], 0);
  for (const residual of Object.values(r.physicalVoltageResidual)) close(residual, 0);
  for (let i = 0; i < 2; i++) {
    const row = r.rows[i]; close(row.forceWorkResidual, 0);
    assert.equal(row.beforeSolve.bodyId, fixture.bodies[i].id); assert.equal(row.forceIntegrated.shapeId, fixture.shapes[i].id);
    assert.deepEqual(row.forceIntegrated.p, vector(fixture.bodies[i].position)); assert.deepEqual(row.forceIntegrated.v, vector(fixture.bodies[i].velocity));
    for (let k = 0; k < 3; k++) close(row.totalQueuedForce[k], row.pendingForce[k] + row.electricalForce[k]);
    assert.ok(row.forceBEDefect >= 0); assert.ok(row.nativeDampingLoss >= -1e-10);
  }
  for (const key of ['generatorHeat', 'motorHeat', 'diodeHeat', 'physicalHeat', 'capacitorBEDefect', 'forceBEDefect']) assert.ok(e[key] >= 0);
  close(e.physicalHeat, e.generatorHeat + e.motorHeat + e.diodeHeat);
  // This is an electrical numerical-elimination coefficient, not heat. Its
  // distinct positive amount must not be added to physical dissipation.
  assert.ok(e.effectiveResistanceTermsNotHeat.generator >= 0 && e.effectiveResistanceTermsNotHeat.motor >= 0);
}

for (const h of [1 / 120, 1 / 240]) for (const velocity of [-6, 6]) test(`Native post-damping signed motion ${velocity}, ${1 / h}Hz`, () => {
  const f = fixture({velocity}); try {
    const steps = Math.round(1.5 / h);
    for (let i = 0; i < steps; i++) check(f.step(h), f, h);
    const s = f.adapter.snapshot(); assert.equal(s.steps, steps); assert.ok(s.voltage > 0); assert.ok(s.totals.generatorWorkActual > 0); assert.ok(s.totals.motorWorkActual > 0);
    close(s.totals.combinedResidual, 0, 2e-7);
  } finally { f.dispose(); }
});

test('Capacitor drive and mechanical backdrive retain signed actual displacement work', () => {
  for (const options of [{velocity: 0, circuit: {initialVoltage: 8}}, {velocity: 0, motorVelocity: 5, circuit: {initialVoltage: 3}}]) {
    const f = fixture(options); try {
      check(f.step(1 / 120), f, 1 / 120); const e = f.adapter.snapshot().latest.ledger;
      if (options.motorVelocity) { assert.ok(e.motorWorkActual < 0); assert.ok(e.capacitorDelta > 0); }
      else { assert.ok(e.motorWorkActual > 0); assert.ok(e.capacitorDelta < 0); }
    } finally { f.dispose(); }
  }
});

test('Actual wrong bridge graph gives no forward motor work from either generator sign', () => {
  for (const velocity of [-6, 6]) {
    const f = fixture({velocity, circuit: {diodes: ROOM44_SWAPPED_AC_DC_DIODE_PORTS}}); try {
      for (let i = 0; i < 120; i++) check(f.step(1 / 120), f, 1 / 120);
      const s = f.adapter.snapshot(); close(s.voltage, 0, 1e-9); close(s.totals.motorWorkActual, 0, 1e-9);
    } finally { f.dispose(); }
  }
});

test('Reversed actual motor leads produce reverse native motion', () => {
  const f = fixture({circuit: {motorPorts: ['N', 'P']}}); try {
    for (let i = 0; i < 120; i++) check(f.step(1 / 120), f, 1 / 120);
    assert.ok(f.motor.position.y < -.01); assert.ok(f.adapter.snapshot().latest.electrical.motorCurrent < 0);
  } finally { f.dispose(); }
});

test('An explicitly paid force reverses the native source without setting its velocity', () => {
  const f = fixture(); let positive = false, negative = false; try {
    for (let i = 0; i < 180; i++) {
      f.generator.applyForce(new Vec3(0, 0, -50));
      const s = f.step(1 / 120); check(s, f, 1 / 120);
      positive ||= s.latest.electrical.generatorCurrent > 1e-6; negative ||= s.latest.electrical.generatorCurrent < -1e-6;
    }
    assert.ok(positive && negative); assert.ok(f.generator.velocity.z < 0);
    assert.ok(f.adapter.snapshot().totals.pendingForceWork !== 0);
  } finally { f.dispose(); }
});

test('Earlier preStep force contributors and full 3D pending work remain present', () => {
  const f = fixture({contributor: ({generator, motor}) => {
    generator.applyForce(new Vec3(.4, -.2, .7)); motor.applyForce(new Vec3(-.2, .3, .1));
    generator.torque.vadd(new Vec3(.01, -.02, .03), generator.torque);
  }}); try {
    for (let i = 0; i < 30; i++) {
      const s = f.step(1 / 120); check(s, f, 1 / 120);
      assert.deepEqual(s.latest.rows[0].pendingForce, [.4, -.2, .7]);
      assert.deepEqual(s.latest.rows[0].damped.torque, [.01, -.02, .03]);
    }
    assert.ok(f.generator.velocity.x > 0 && f.motor.velocity.x < 0);
  } finally { f.dispose(); }
});

test('Real contact stabilization is retained as signed solver work, never physical heat', () => {
  const f = fixture({velocity: 0, gravity: -19.5, contact: true, circuit: {initialVoltage: 8}}); let positiveSolver = false, contacts = false; try {
    for (let i = 0; i < 32; i++) {
      const s = f.step(1 / 120); check(s, f, 1 / 120);
      positiveSolver ||= s.latest.rows[0].solverKineticDeltaSigned > 1e-6; contacts ||= s.latest.nativeContacts > 0;
    }
    assert.ok(contacts && positiveSolver, 'The actual initially penetrating contact may inject stabilization kinetic energy');
    assert.equal(f.adapter.snapshot().globalRigidBodyConservationAccepted, false);
  } finally { f.dispose(); }
});

test('Post-solver electrical forces expose constraint delay rather than claiming a coupled solve', () => {
  const f = fixture({generatorAxis: [1, 0, 0], motorAxis: [1, 0, 0], link: true}); try {
    const s = f.step(1 / 120); check(s, f, 1 / 120); assert.equal(s.latest.nativeConstraints, 1);
    assert.ok(Math.abs(f.motor.velocity.x - f.generator.velocity.x) > 1e-6, 'The force kick occurs after the constraint solve and can reopen its velocity residual');
    assert.equal(s.fullyCoupledConstraintsAccepted, false);
  } finally { f.dispose(); }
});

test('Late listener changes fail at the read-only boundary without touching forces, clocks or capacitor', () => {
  for (const type of ['preStep', 'postStep']) {
    const f = fixture(), late = () => {}; try {
      f.generator.force.set(.2, .3, .4); f.generator.torque.set(.5, .6, .7);
      const before = {force: vector(f.generator.force), torque: vector(f.generator.torque), time: f.world.time, step: f.world.stepnumber, electrical: f.adapter.snapshot()};
      f.world.addEventListener(type, late); assert.throws(() => f.adapter.validateBoundary());
      assert.deepEqual(vector(f.generator.force), before.force); assert.deepEqual(vector(f.generator.torque), before.torque);
      assert.equal(f.world.time, before.time); assert.equal(f.world.stepnumber, before.step); assert.deepEqual(f.adapter.snapshot(), before.electrical);
      f.world.removeEventListener(type, late); assert.equal(f.adapter.validateBoundary(), true);
    } finally { f.world.removeEventListener(type, late); f.dispose(); }
  }
});

test('Replaced listener arrays reject the step and dispose removes owned callbacks from both arrays', () => {
  for (const replaceObject of [false, true]) {
    const f = fixture(), foreign = () => {}; try {
      const original = f.world._listeners.preStep;
      if (replaceObject) f.world._listeners = {...f.world._listeners};
      f.world._listeners.preStep = [...original];
      assert.throws(() => f.adapter.validateBoundary(), /inventories/);
      f.world.addEventListener('preStep', foreign);
      f.adapter.dispose(); assert.equal(original.length, 0); assert.equal(f.world.hasEventListener('preStep', foreign), true);
      assert.equal(f.world.solver.solve, f.nativeSolve);
    } finally { f.world.removeEventListener('preStep', foreign); f.dispose(); }
  }
});

test('A preStep impulse from another owner is detected before electrical force queue or capacitor commit', () => {
  const f = fixture({contributor: ({generator}) => generator.applyImpulse(new Vec3(.2, 0, 0))});
  const before = f.adapter.snapshot(); try {
    assert.throws(() => f.world.step(1 / 120), /damping/);
    const after = f.adapter.snapshot(); assert.equal(after.voltage, before.voltage); assert.equal(after.steps, 0);
    assert.deepEqual(vector(f.generator.force), [0, 0, 0]); assert.deepEqual(vector(f.motor.force), [0, 0, 0]);
    assert.ok(f.generator.velocity.x > 0, 'The negative physical impulse fixture is not rewound by the adapter');
  } finally { f.dispose(); }
});

test('Constructor rejects automatic-sleep and altered-factor fixtures before owning native hooks', () => {
  const physics = new LabPhysics({gravity: 0}), world = physics.world;
  const original = physics.createCargo(), motor = new Body({mass: 5, shape: new Box(new Vec3(.3, .4, .3))}); world.addBody(motor);
  const solve = world.solver.solve, before = {force: vector(original.force), torque: vector(original.torque), p: vector(original.position), v: vector(original.velocity), time: world.time, step: world.stepnumber};
  try {
    assert.equal(world.allowSleep, true);
    assert.throws(() => new NativePreStepBridgeAdapter({world, generatorBody: original, motorBody: motor}), /allowSleep/);
    world.allowSleep = false; // Explicit second constructor fixture, before any native step.
    const invalid = new Body({mass: 3.2, shape: new Box(new Vec3(.39, .39, .39)), material: physics.cargoMaterial,
      linearDamping: .035, angularDamping: .16, linearFactor: new Vec3(1, 1, 0)}); world.addBody(invalid);
    assert.throws(() => new NativePreStepBridgeAdapter({world, generatorBody: invalid, motorBody: motor}), /linearFactor/);
    const fakeSolve = () => 0; world.solver.solve = fakeSolve; // Declared negative owner fixture, no World.step.
    assert.throws(() => new NativePreStepBridgeAdapter({world, generatorBody: original, motorBody: motor}), /native GSSolver/);
    assert.equal(world.solver.solve, fakeSolve, 'Invalid construction must preserve the foreign solver owner');
    world.solver.solve = solve;
    Object.freeze(motor.force); // Declared malformed owned-motor fixture; no World.step.
    assert.throws(() => new NativePreStepBridgeAdapter({world, generatorBody: original, motorBody: motor}), /writable native force/);
    assert.equal(world.solver.solve, solve); assert.equal(world._listeners?.preStep?.length ?? 0, 0); assert.equal(world._listeners?.postStep?.length ?? 0, 0);
    assert.deepEqual({force: vector(original.force), torque: vector(original.torque), p: vector(original.position), v: vector(original.velocity), time: world.time, step: world.stepnumber}, before);
  } finally { physics.dispose(); }
});

test('Disposal restores native owners once and preserves pre-existing force, torque, clocks and capacitor', () => {
  const f = fixture(); try {
    check(f.step(1 / 120), f, 1 / 120);
    f.generator.force.set(.2, .3, .4); f.generator.torque.set(.5, .6, .7); f.motor.force.set(-.2, -.3, -.4);
    const before = {force: vector(f.generator.force), torque: vector(f.generator.torque), motorForce: vector(f.motor.force), p: vector(f.generator.position), v: vector(f.generator.velocity), time: f.world.time, step: f.world.stepnumber, voltage: f.adapter.snapshot().voltage};
    f.adapter.dispose(); f.adapter.dispose(); assert.equal(f.world.solver.solve, f.nativeSolve);
    assert.deepEqual({force: vector(f.generator.force), torque: vector(f.generator.torque), motorForce: vector(f.motor.force), p: vector(f.generator.position), v: vector(f.generator.velocity), time: f.world.time, step: f.world.stepnumber, voltage: f.adapter.snapshot().voltage}, before);
  } finally { f.dispose(); }
});
